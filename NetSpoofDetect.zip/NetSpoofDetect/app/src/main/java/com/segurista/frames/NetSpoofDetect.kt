package com.segurista.frames

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.segurista.frames.pages.Adapter.MyVpnService
import java.io.File


class NetSpoofDetect : AppCompatActivity() {

    private lateinit var txtStatus: TextView
    private lateinit var txtLogs: TextView
    private val logBuilder = StringBuilder()

    private val database = FirebaseDatabase.getInstance()
    private var dnsResponses = mutableMapOf<String, String>()
    private var safeDomains = mutableMapOf<String, String>()



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_net_spoof_detect)

        txtStatus = findViewById(R.id.txtStatus)
        txtLogs = findViewById(R.id.txtLogs)

        findViewById<Button>(R.id.btnScan).setOnClickListener {
            txtStatus.text = "Status: Scanning..."
            logToScreen("🔍 Scanning for spoofing threats...")

            fetchMappingsAndStartScan()
        }

        findViewById<Button>(R.id.btnSaveLogs).setOnClickListener {
            startLogsToFile()
        }
    }

    private fun fetchMappingsAndStartScan() {
        val spoofedRef = database.getReference("dnsMappings/spoofed")
        val safeRef = database.getReference("dnsMappings/safe")

        spoofedRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(spoofedSnapshot: DataSnapshot) {
                safeRef.addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(safeSnapshot: DataSnapshot) {
                        dnsResponses = mutableMapOf()
                        safeDomains = mutableMapOf()

                        spoofedSnapshot.children.forEach {
                            val key = it.key ?: return@forEach
                            val value = it.getValue(String::class.java) ?: ""
                            dnsResponses[key] = value
                        }

                        safeSnapshot.children.forEach {
                            val key = it.key ?: return@forEach
                            val value = it.getValue(String::class.java) ?: ""
                            safeDomains[key] = value
                        }

                        detectDnsSpoof()
                        startVpnService()
                    }

                    override fun onCancelled(error: DatabaseError) {
                        showError("Failed to load safe DNS data")
                    }
                })
            }

            override fun onCancelled(error: DatabaseError) {
                showError("Failed to load spoofed DNS data")
            }
        })
    }

    private fun detectDnsSpoof() {
        val logsRef = database.getReference("logs")
        val timestamp = System.currentTimeMillis().toString()
        var threatFound = false
        val logEntries = mutableListOf<Map<String, String>>() // List to hold log items

        for ((rawDomain, resolvedIp) in dnsResponses) {
            val domain = rawDomain.replace("_", ".")
            val expectedIp = safeDomains[rawDomain]

            logToScreen("🔎 Checking $domain → Resolved: $resolvedIp | Expected: $expectedIp")

            if (expectedIp != null && resolvedIp != expectedIp) {
                val alertMsg = "⚠️ DNS Spoof Detected: $domain → $resolvedIp (Expected: $expectedIp)"
                logToScreen(alertMsg)
                sendThreatNotification(this, "DNS Spoof Detected", alertMsg)

                logEntries.add(
                    mapOf(
                        "domain" to domain,
                        "resolvedIp" to resolvedIp,
                        "expectedIp" to expectedIp,
                        "timestamp" to timestamp
                    )
                )

                threatFound = true
            } else {
                logToScreen("✅ $domain is safe ($resolvedIp)")
            }
        }

        if (logEntries.isNotEmpty()) {
            logsRef.child(timestamp).setValue(logEntries)
                .addOnSuccessListener {
                    logToScreen("✅ Detection logs saved to Firebase.")
                }
                .addOnFailureListener {
                    logToScreen("⚠️ Failed to save logs.")
                }
        }

        txtStatus.text = if (threatFound) "Status: Threat Detected" else "Status: No Threats Found"
    }

    private fun detectArpSpoof() {
        val logsRef = database.getReference("logs")
        val timestamp = System.currentTimeMillis().toString()
        val suspiciousEntries = mutableListOf<Map<String, String>>()

        try {
            val arpFile = File("/proc/net/arp")
            if (arpFile.exists()) {
                val lines = arpFile.readLines().drop(1)
                val macMap = mutableMapOf<String, String>()

                for (line in lines) {
                    val parts = line.split("\\s+".toRegex())
                    if (parts.size >= 4) {
                        val ip = parts[0]
                        val mac = parts[3]

                        if (mac != "00:00:00:00:00:00" && mac.isNotEmpty()) {
                            if (macMap.containsValue(mac) && macMap[ip] != mac) {
                                val msg = "⚠️ ARP spoofing? Duplicate MAC $mac for IP $ip"
                                logToScreen(msg)
                                sendThreatNotification(this, "ARP Spoof Detected", msg)

                                suspiciousEntries.add(
                                    mapOf(
                                        "type" to "ARP",
                                        "ip" to ip,
                                        "mac" to mac,
                                        "timestamp" to timestamp
                                    )
                                )
                            }
                            macMap[ip] = mac
                        }
                    }
                }
            }
        } catch (e: Exception) {
            logToScreen("⚠️ Error reading ARP table: ${e.message}")
        }

        if (suspiciousEntries.isNotEmpty()) {
            logsRef.child("arp").child(timestamp).setValue(suspiciousEntries)
                .addOnSuccessListener {
                    logToScreen("✅ ARP detection logs saved to Firebase.")
                }
                .addOnFailureListener {
                    logToScreen("⚠️ Failed to save ARP logs.")
                }
        } else {
            logToScreen("✅ No ARP spoofing detected.")
        }
    }

    private fun sendThreatNotification(context: Context, title: String, message: String) {
        val channelId = "threat_alerts"
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Threat Alerts", NotificationManager.IMPORTANCE_HIGH)
            manager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle(title)
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()

        manager.notify(System.currentTimeMillis().toInt(), notification)
    }

    private fun logToScreen(message: String) {
        logBuilder.append("$message\n")
        txtLogs.text = logBuilder.toString()
    }

    private fun showError(msg: String) {
        Toast.makeText(this, "\u26A0\uFE0F $msg", Toast.LENGTH_SHORT).show()
    }

    private fun startLogsToFile() {
        Toast.makeText(this, "📁 Logs saved for reporting (simulated)", Toast.LENGTH_SHORT).show()
    }

    private fun startVpnService() {
        val intent = VpnService.prepare(this)
        if (intent != null) {
            startActivityForResult(intent, 0)
        } else {
            onActivityResult(0, RESULT_OK, null)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            val vpnIntent = Intent(this, MyVpnService::class.java)
            startService(vpnIntent)
            Toast.makeText(this, "VPN started", Toast.LENGTH_SHORT).show()
        }
    }


}