package com.segurista.frames.pages.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.segurista.frames.R
import com.segurista.frames.pages.DataModels.DeviceInfo

class DeviceAdapter(private val devices: List<DeviceInfo>) :
    RecyclerView.Adapter<DeviceAdapter.DeviceViewHolder>() {

    class DeviceViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val txtInfo: TextView = view.findViewById(R.id.txtDeviceInfo)
        val txtPorts: TextView = view.findViewById(R.id.txtPortInfo)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DeviceViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_device, parent, false)
        return DeviceViewHolder(view)
    }

    override fun onBindViewHolder(holder: DeviceViewHolder, position: Int) {
        val device = devices[position]
        holder.txtInfo.text = "🟢 ${device.ip} (${device.hostname})\nMAC: ${device.mac}"
        holder.txtPorts.text = device.openPorts.joinToString("\n") {
            "Port ${it.port} — ${it.riskLevel} Risk"
        }
    }

    override fun getItemCount() = devices.size
}