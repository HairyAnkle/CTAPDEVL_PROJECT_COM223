package com.segurista.frames.pages.Adapter

import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import kotlinx.coroutines.*
import java.io.FileInputStream
import java.nio.ByteBuffer

class MyVpnService: VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private var vpnJob: Job? = null

    override fun onStartCommand(intent: android.content.Intent?, flags: Int, startId: Int): Int {
        setupVpn()
        return START_STICKY
    }

    private fun setupVpn() {
        val builder = Builder()
        builder.setSession("Spoofing Detection VPN")
            .addAddress("10.0.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .setBlocking(true)

        vpnInterface = builder.establish()
        vpnJob = CoroutineScope(Dispatchers.IO).launch {
            val inputStream = FileInputStream(vpnInterface!!.fileDescriptor)
            val channel = inputStream.channel
            val buffer = ByteBuffer.allocate(32767)

            while (isActive) {
                buffer.clear()
                val readBytes = channel.read(buffer)
                if (readBytes > 0) {
                    buffer.flip()
                    inspectPacket(buffer)
                }
            }
        }
    }

    private fun inspectPacket(buffer: ByteBuffer) {
        val data = ByteArray(buffer.remaining())
        buffer.get(data)

        // Check if it's UDP (protocol 17) and ports are DNS (53)
        if (data.size > 42 && data[23] == 17.toByte()) {
            val srcPort = ((data[34].toInt() and 0xFF) shl 8) or (data[35].toInt() and 0xFF)
            val dstPort = ((data[36].toInt() and 0xFF) shl 8) or (data[37].toInt() and 0xFF)
            if (srcPort == 53 || dstPort == 53) {
                Log.d("DnsCapture", "🕵️ DNS packet detected")

                val dnsStart = 42 // Typical DNS payload offset (Ethernet + IP + UDP headers)

                try {
                    // Skip DNS header (12 bytes)
                    var offset = dnsStart + 12

                    // Parse Question Section (basic implementation, one question only)
                    val domain = StringBuilder()
                    var length = data[offset++].toInt()
                    while (length > 0) {
                        for (i in 0 until length) {
                            domain.append(data[offset++].toInt().toChar())
                        }
                        domain.append(".")
                        length = data[offset++].toInt()
                    }
                    domain.setLength(domain.length - 1) // remove trailing dot

                    // Skip QTYPE (2 bytes) + QCLASS (2 bytes)
                    offset += 4

                    val queriedDomain = domain.toString()
                    Log.d("DnsCapture", "🔍 Queried domain: $queriedDomain")

                    // Start parsing Answer section (assuming 1 answer for simplicity)
                    offset += 2 // Skip name pointer (e.g., 0xc0 0x0c)
                    val type = ((data[offset].toInt() and 0xFF) shl 8) or (data[offset + 1].toInt() and 0xFF)
                    offset += 8 // Skip TYPE, CLASS, TTL (4 bytes)

                    val rdLength = ((data[offset].toInt() and 0xFF) shl 8) or (data[offset + 1].toInt() and 0xFF)
                    offset += 2

                    if (type == 1 && rdLength == 4) { // A record (IPv4)
                        val ip = "${data[offset].toInt() and 0xFF}." +
                                "${data[offset + 1].toInt() and 0xFF}." +
                                "${data[offset + 2].toInt() and 0xFF}." +
                                "${data[offset + 3].toInt() and 0xFF}"
                        Log.d("DnsCapture", "📦 DNS Response IP: $ip")

                        // 🔐 Compare against known good IPs (fake list)
                        val knownIPs = mapOf(
                            "google.com" to "8.8.8.8",
                            "facebook.com" to "157.240.20.35"
                        )

                        if (knownIPs.containsKey(queriedDomain)) {
                            if (ip != knownIPs[queriedDomain]) {
                                Log.w("DnsCapture", "⚠️ DNS spoofing suspected for $queriedDomain → $ip")
                                // Trigger alert or log suspicious activity
                            } else {
                                Log.d("DnsCapture", "✅ Valid DNS response for $queriedDomain")
                            }
                        }
                    }

                } catch (e: Exception) {
                    Log.e("DnsCapture", "Error parsing DNS response: ${e.message}")
                }
            }
        }
    }

    override fun onDestroy() {
        vpnJob?.cancel()
        vpnInterface?.close()
        super.onDestroy()
    }
}