package com.segurista.frames.pages.DataModels


data class DeviceInfo(
    val ip: String,
    val mac: String,
    val hostname: String,
    val openPorts: List<PortInfo>
)

data class PortScanResult(
    val port: Int,
    val riskLevel: String
)

data class PortInfo(val port: Int, val riskLevel: String)
