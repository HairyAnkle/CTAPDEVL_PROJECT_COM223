package com.cybersec.netspoof.data.entities

import java.util.Date

data class Device(
    val macAddress: String,
    val ipAddress: String,
    val deviceName: String,
    val manufacturer: String? = null,
    val deviceType: String = "Unknown",
    val isIoTDevice: Boolean = false,
    val lastSeen: Date = Date(),
    val isOnline: Boolean = true,
    val openPorts: List<Int> = emptyList()
)
