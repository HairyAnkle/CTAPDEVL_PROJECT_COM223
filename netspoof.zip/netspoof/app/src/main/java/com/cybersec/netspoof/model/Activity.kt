package com.cybersec.netspoof.model

import java.util.UUID

enum class ActivityType {
    SCAN_STARTED,
    SCAN_COMPLETED,
    THREAT_DETECTED,
    THREAT_RESOLVED,
    DEVICE_CONNECTED,
    DEVICE_DISCONNECTED,
    SYSTEM
}

data class NetworkActivity(
    val id: String = UUID.randomUUID().toString(),
    val type: ActivityType,
    val title: String,
    val description: String,
    val timestamp: Long = System.currentTimeMillis(),
    val relatedDeviceId: String? = null,
    val relatedThreatId: String? = null,
    val status: SecurityStatus = SecurityStatus.SECURE
)