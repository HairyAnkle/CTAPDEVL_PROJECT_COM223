package com.cybersec.netspoof.model

import java.util.UUID

enum class DeviceType {
    SMARTPHONE,
    TABLET,
    LAPTOP,
    DESKTOP,
    SMART_TV,
    GAME_CONSOLE,
    IOT_DEVICE,
    ROUTER,
    IOT,
    UNKNOWN
}

data class Device(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val ip: String,
    val mac: String,
    val vendor: String = "Unknown",
    val type: DeviceType = DeviceType.UNKNOWN,
    val isVulnerable: Boolean = false,
    val vulnerabilityCount: Int = 0,
    val lastSeen: Long = System.currentTimeMillis(),
    val isOnline: Boolean = true
)
