package com.cybersec.netspoof.model

enum class SecurityStatus {
    SECURE,
    WARNING,
    DANGER
}

data class NetworkStatus(
    val status: SecurityStatus = SecurityStatus.SECURE,
    val description: String = "No threats detected",
    val lastScanTime: Long = System.currentTimeMillis()
)
