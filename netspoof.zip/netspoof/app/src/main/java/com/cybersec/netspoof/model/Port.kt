package com.cybersec.netspoof.model

import java.util.UUID

enum class PortStatus {
    OPEN,
    CLOSED,
    FILTERED
}

data class Port(
    val id: String = UUID.randomUUID().toString(),
    val number: Int,
    val service: String,
    val status: PortStatus,
    val deviceId: String,
    val protocol: String = "TCP"
)
