package com.cybersec.netspoof.model

import com.cybersec.netspoof.repo.ScanType
import java.util.Date

data class ScanResult(
    val id: String,
    val scanType: ScanType,
    val scanDate: Date,
    val duration: Long,
    val devicesScanned: Int,
    val threatsFound: Int,
    val vulnerabilitiesFound: Int,
    val devices: List<Device> = emptyList(),
    val threats: List<Threat> = emptyList(),
    val vulnerabilities: List<Vulnerability> = emptyList()
)
