package com.cybersec.netspoof.model

data class ScanResultItem(
    val id: String,
    val title: String,
    val description: String,
    val deviceInfo: String,
    val severity: String,
    val type: String
)
