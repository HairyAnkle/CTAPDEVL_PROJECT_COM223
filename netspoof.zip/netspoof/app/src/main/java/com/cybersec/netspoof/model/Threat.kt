package com.cybersec.netspoof.model

import java.util.UUID

enum class ThreatType {
    ARP_SPOOFING,
    DNS_SPOOFING,
    ROGUE_DEVICE,
    MAN_IN_THE_MIDDLE,
    VULNERABILITY
}

enum class ThreatSeverity {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}

data class Threat(
    val id: String = UUID.randomUUID().toString(),
    val type: ThreatType,
    val title: String,
    val description: String,
    val deviceIp: String? = null,
    val deviceMac: String? = null,
    val severity: ThreatSeverity,
    val timestamp: Long = System.currentTimeMillis(),
    val isActive: Boolean = true
)
