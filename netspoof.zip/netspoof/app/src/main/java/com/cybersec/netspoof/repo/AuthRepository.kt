package com.cybersec.netspoof.repo

import android.content.Context
import com.cybersec.netspoof.R
import com.cybersec.netspoof.model.User
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import kotlinx.coroutines.tasks.await
import java.lang.Exception

class AuthRepository {
    private val firebaseAuth = FirebaseAuth.getInstance()
    private lateinit var googleSignInClient: GoogleSignInClient


    // Initialize Google Sign-In
    fun initGoogleSignIn(context: Context) {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(context.getString(R.string.default_web_client_id))
            .requestEmail()
            .build()
        googleSignInClient = GoogleSignIn.getClient(context, gso)
    }

    // Get Google Sign-In Client
    fun getGoogleSignInClient(): GoogleSignInClient {
        return googleSignInClient
    }

    // Convert FirebaseUser to our User model
    private fun mapFirebaseUser(firebaseUser: FirebaseUser?): User? {
        return firebaseUser?.let {
            User(
                uid = it.uid,
                email = it.email ?: "",
                displayName = it.displayName ?: "",
                photoUrl = it.photoUrl?.toString() ?: ""
            )
        }
    }

    // Get current user
    fun getCurrentUser(): User? {
        return mapFirebaseUser(firebaseAuth.currentUser)
    }

    // Check if user is logged in
    fun isLoggedIn(): Boolean {
        return firebaseAuth.currentUser != null
    }

    // Login with email and password
    suspend fun login(email: String, password: String): Result<User> {
        return try {
            val authResult = firebaseAuth.signInWithEmailAndPassword(email, password).await()
            val user = mapFirebaseUser(authResult.user)
            if (user != null) {
                Result.success(user)
            } else {
                Result.failure(Exception("Authentication failed"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Register with email and password
    suspend fun register(email: String, password: String, displayName: String = ""): Result<User> {
        return try {
            val authResult = firebaseAuth.createUserWithEmailAndPassword(email, password).await()
            val firebaseUser = authResult.user

            // Update display name if provided
            if (displayName.isNotEmpty() && firebaseUser != null) {
                val profileUpdates = UserProfileChangeRequest.Builder()
                    .setDisplayName(displayName)
                    .build()
                firebaseUser.updateProfile(profileUpdates).await()
            }

            val user = mapFirebaseUser(firebaseUser)
            if (user != null) {
                Result.success(user)
            } else {
                Result.failure(Exception("Registration failed"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Sign in with Google
    suspend fun signInWithGoogle(googleAccount: GoogleSignInAccount): Result<User> {
        return try {
            val credential = GoogleAuthProvider.getCredential(googleAccount.idToken, null)
            val authResult = firebaseAuth.signInWithCredential(credential).await()
            val user = mapFirebaseUser(authResult.user)
            if (user != null) {
                Result.success(user)
            } else {
                Result.failure(Exception("Google authentication failed"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Forgot password
    suspend fun sendPasswordResetEmail(email: String): Result<Unit> {
        return try {
            firebaseAuth.sendPasswordResetEmail(email).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Logout
    fun logout() {
        firebaseAuth.signOut()
        googleSignInClient.signOut()
    }


}
