package com.cybersec.netspoof.repo

import android.content.Context
import com.cybersec.netspoof.model.*
import com.cybersec.netspoof.service.ScanProgress
import com.cybersec.netspoof.utils.ArpSpoofDetector
import com.cybersec.netspoof.utils.DnsSpoofDetector
import com.cybersec.netspoof.utils.NetworkScanner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ConcurrentHashMap

class NetworkRepository(private val context: Context) {

    private val arpSpoofDetector = ArpSpoofDetector(context)
    private val dnsSpoofDetector = DnsSpoofDetector(context)
    private val networkScanner = NetworkScanner(context)

    private var cachedDevices = mutableListOf<Device>()
    private var cachedThreats = mutableListOf<Threat>()
    private var cachedActivities = mutableListOf<NetworkActivity>()
    private var cachedScanResults = ConcurrentHashMap<String, ScanResult>()
    private var lastScanTime = 0L

    // Get current network status
    fun getNetworkStatus(): Flow<NetworkStatus> = flow {
        // Check if we have cached threats
        val status = when {
            cachedThreats.any { it.severity == ThreatSeverity.HIGH || it.severity == ThreatSeverity.CRITICAL } ->
                SecurityStatus.DANGER
            cachedThreats.isNotEmpty() -> SecurityStatus.WARNING
            else -> SecurityStatus.SECURE
        }

        val description = when (status) {
            SecurityStatus.SECURE -> "No threats detected"
            SecurityStatus.WARNING -> "Potential threats detected"
            SecurityStatus.DANGER -> "Active threats detected"
        }

        emit(NetworkStatus(status, description, lastScanTime))
    }.flowOn(Dispatchers.IO)

    // Get active threats
    fun getActiveThreats(): Flow<List<Threat>> = flow {
        emit(cachedThreats)
    }.flowOn(Dispatchers.IO)

    // Get connected devices
    fun getConnectedDevices(): Flow<List<Device>> = flow {
        emit(cachedDevices)
    }.flowOn(Dispatchers.IO)

    // Get device by ID
    fun getDeviceById(deviceId: String): Flow<Device?> = flow {
        val device = cachedDevices.find { it.id == deviceId }
        emit(device)
    }.flowOn(Dispatchers.IO)

    // Get device ports
    fun getDevicePorts(deviceId: String): Flow<List<Port>> = flow {
        // In a real app, this would come from actual port scanning
        val ports = mutableListOf<Port>()

        // Add mock ports based on device ID
        val device = cachedDevices.find { it.id == deviceId }
        if (device != null) {
            when (device.type) {
                DeviceType.SMARTPHONE -> {
                    // Phone typically has fewer open ports
                    ports.add(Port(number = 80, service = "HTTP", status = PortStatus.OPEN, deviceId = deviceId))
                    ports.add(Port(number = 443, service = "HTTPS", status = PortStatus.OPEN, deviceId = deviceId))
                }
                DeviceType.SMART_TV -> {
                    // Smart TV might have more services
                    ports.add(Port(number = 80, service = "HTTP", status = PortStatus.OPEN, deviceId = deviceId))
                    ports.add(Port(number = 443, service = "HTTPS", status = PortStatus.OPEN, deviceId = deviceId))
                    ports.add(Port(number = 8008, service = "HTTP Alt", status = PortStatus.OPEN, deviceId = deviceId))
                    ports.add(Port(number = 8009, service = "HTTP Alt", status = PortStatus.OPEN, deviceId = deviceId))
                    ports.add(Port(number = 9080, service = "WebUI", status = PortStatus.OPEN, deviceId = deviceId))
                }
                DeviceType.ROUTER -> {
                    // Router typically has management ports
                    ports.add(Port(number = 80, service = "HTTP", status = PortStatus.OPEN, deviceId = deviceId))
                    ports.add(Port(number = 443, service = "HTTPS", status = PortStatus.OPEN, deviceId = deviceId))
                    ports.add(Port(number = 22, service = "SSH", status = PortStatus.OPEN, deviceId = deviceId))
                    ports.add(Port(number = 23, service = "Telnet", status = PortStatus.OPEN, deviceId = deviceId))
                    ports.add(Port(number = 53, service = "DNS", status = PortStatus.OPEN, deviceId = deviceId))
                    ports.add(Port(number = 67, service = "DHCP", status = PortStatus.OPEN, deviceId = deviceId))
                }
                else -> {
                    // Default ports for unknown devices
                    ports.add(Port(number = 80, service = "HTTP", status = PortStatus.OPEN, deviceId = deviceId))
                }
            }
        }

        emit(ports)
    }.flowOn(Dispatchers.IO)

    // Get device vulnerabilities
    fun getDeviceVulnerabilities(deviceId: String): Flow<List<Vulnerability>> = flow {
        // In a real app, this would come from actual vulnerability scanning
        val vulnerabilities = mutableListOf<Vulnerability>()

        // Add mock vulnerabilities based on device ID
        val device = cachedDevices.find { it.id == deviceId }
        if (device != null) {
            when (device.type) {
                DeviceType.SMARTPHONE -> {
                    // Phone typically has fewer vulnerabilities
                }
                DeviceType.SMART_TV -> {
                    // Smart TV might have more vulnerabilities
                    vulnerabilities.add(
                        Vulnerability(
                            id = UUID.randomUUID().toString(),
                            title = "Default Credentials",
                            description = "Device is using default manufacturer credentials for web interface",
                            severity = VulnerabilitySeverity.HIGH,
                            deviceId = deviceId,
                            deviceIp = device.ip,
                            recommendation = "Change default credentials or disable web interface if not needed"
                        )
                    )
                    vulnerabilities.add(
                        Vulnerability(
                            id = UUID.randomUUID().toString(),
                            title = "Outdated Firmware",
                            description = "Device is running an outdated firmware version with known security issues",
                            severity = VulnerabilitySeverity.MEDIUM,
                            deviceId = deviceId,
                            deviceIp = device.ip,
                            recommendation = "Update device firmware to the latest version"
                        )
                    )
                }
                DeviceType.ROUTER -> {
                    // Router might have critical vulnerabilities
                    vulnerabilities.add(
                        Vulnerability(
                            id = UUID.randomUUID().toString(),
                            title = "Telnet Enabled",
                            description = "Telnet service is enabled which transmits data in plaintext",
                            severity = VulnerabilitySeverity.HIGH,
                            deviceId = deviceId,
                            deviceIp = device.ip,
                            recommendation = "Disable Telnet and use SSH instead"
                        )
                    )
                }
                DeviceType.IOT -> {
                    // IoT devices often have many vulnerabilities
                    vulnerabilities.add(
                        Vulnerability(
                            id = UUID.randomUUID().toString(),
                            title = "Unencrypted Communication",
                            description = "Device is communicating with cloud services without encryption",
                            severity = VulnerabilitySeverity.HIGH,
                            deviceId = deviceId,
                            deviceIp = device.ip,
                            recommendation = "Check if firmware updates are available to enable encryption"
                        )
                    )
                    vulnerabilities.add(
                        Vulnerability(
                            id = UUID.randomUUID().toString(),
                            title = "No Authentication",
                            description = "Device web interface has no authentication",
                            severity = VulnerabilitySeverity.CRITICAL,
                            deviceId = deviceId,
                            deviceIp = device.ip,
                            recommendation = "Enable authentication or restrict access to the device"
                        )
                    )
                }
                else -> {
                    // Unknown devices might have generic vulnerabilities
                    vulnerabilities.add(
                        Vulnerability(
                            id = UUID.randomUUID().toString(),
                            title = "Unknown Services",
                            description = "Device is running unknown services on ports 8080 and 9000",
                            severity = VulnerabilitySeverity.MEDIUM,
                            deviceId = deviceId,
                            deviceIp = device.ip,
                            recommendation = "Investigate services running on these ports"
                        )
                    )
                }
            }
        }

        emit(vulnerabilities)
    }.flowOn(Dispatchers.IO)

    // Get recent activities
    fun getRecentActivities(): Flow<List<NetworkActivity>> = flow {
        emit(cachedActivities)
    }.flowOn(Dispatchers.IO)

    // Start a network scan
    fun startNetworkScan(scanType: ScanType = ScanType.COMPREHENSIVE): Flow<ScanProgress> = flow {
        val scanFlow = when (scanType) {
            ScanType.ARP_SPOOFING -> performArpSpoofingScan()
            ScanType.DNS_SPOOFING -> performDnsSpoofingScan()
            ScanType.VULNERABILITY -> performVulnerabilityScan()
            ScanType.COMPREHENSIVE -> performComprehensiveScan()
        }

        scanFlow.collect { progress ->
            emit(progress)

            // Update cache when scan is complete
            if (progress.progress == 100) {
                updateCacheWithScanResults(progress, scanType)
            }
        }
    }.flowOn(Dispatchers.IO)

    // Start a port scan for a specific device
    fun startPortScan(deviceId: String): Flow<Boolean> = flow {
        emit(false) // Scanning started

        // Perform vulnerability scan which includes port scanning
        performVulnerabilityScan(deviceId).collect { progress ->
            if (progress.progress == 100) {
                // Update device vulnerabilities in cache
                val device = cachedDevices.find { it.id == deviceId }
                if (device != null) {
                    val updatedDevice = device.copy(
                        vulnerabilityCount = progress.vulnerabilities.size,
                        isVulnerable = progress.vulnerabilities.isNotEmpty()
                    )
                    val index = cachedDevices.indexOf(device)
                    if (index >= 0) {
                        cachedDevices[index] = updatedDevice
                    }
                }

                emit(true) // Scanning completed
            }
        }
    }.flowOn(Dispatchers.IO)

    // Start a vulnerability scan for a specific device
    fun startVulnerabilityScan(deviceId: String): Flow<Boolean> = flow {
        emit(false) // Scanning started

        performVulnerabilityScan(deviceId).collect { progress ->
            if (progress.progress == 100) {
                // Update device vulnerabilities in cache
                val device = cachedDevices.find { it.id == deviceId }
                if (device != null) {
                    val updatedDevice = device.copy(
                        vulnerabilityCount = progress.vulnerabilities.size,
                        isVulnerable = progress.vulnerabilities.isNotEmpty()
                    )
                    val index = cachedDevices.indexOf(device)
                    if (index >= 0) {
                        cachedDevices[index] = updatedDevice
                    }
                }

                emit(true) // Scanning completed
            }
        }
    }.flowOn(Dispatchers.IO)

    // Detect ARP spoofing
    suspend fun detectArpSpoofing(): List<Threat> = withContext(Dispatchers.IO) {
        val threats = mutableListOf<Threat>()

        try {
            val arpThreats = arpSpoofDetector.detectArpSpoofing()

            // Convert ARP spoofing threats to our Threat model
            arpThreats.forEach { threatDescription ->
                val severity = if (threatDescription.contains("🚨")) {
                    ThreatSeverity.HIGH
                } else {
                    ThreatSeverity.MEDIUM
                }

                // Extract IP and MAC from threat description if possible
                val ipRegex = Regex("\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b")
                val macRegex = Regex("([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})")

                val ipMatch = ipRegex.find(threatDescription)
                val macMatch = macRegex.find(threatDescription)

                val deviceIp = ipMatch?.value
                val deviceMac = macMatch?.value

                threats.add(
                    Threat(
                        id = UUID.randomUUID().toString(),
                        type = ThreatType.ARP_SPOOFING,
                        title = "ARP Spoofing Detected",
                        description = threatDescription,
                        deviceIp = deviceIp,
                        deviceMac = deviceMac,
                        severity = severity
                    )
                )
            }
        } catch (e: Exception) {
            // Log error
            e.printStackTrace()
        }

        return@withContext threats
    }

    // Detect DNS spoofing
    suspend fun detectDnsSpoofing(): List<Threat> = withContext(Dispatchers.IO) {
        val threats = mutableListOf<Threat>()

        try {
            val dnsThreats = dnsSpoofDetector.detectDnsSpoofing()

            // Convert DNS spoofing threats to our Threat model
            dnsThreats.forEach { threatDescription ->
                val severity = ThreatSeverity.HIGH

                // Extract domain from threat description if possible
                val domainRegex = Regex("\\b(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+[a-z0-9][a-z0-9-]{0,61}[a-z0-9]\\b")
                val ipRegex = Regex("\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b")

                val domainMatch = domainRegex.find(threatDescription)
                val ipMatches = ipRegex.findAll(threatDescription).toList()

                val domain = domainMatch?.value
                val deviceIp = if (ipMatches.size > 1) ipMatches[0].value else null

                threats.add(
                    Threat(
                        id = UUID.randomUUID().toString(),
                        type = ThreatType.DNS_SPOOFING,
                        title = "DNS Spoofing Detected",
                        description = threatDescription,
                        deviceIp = deviceIp,
                        severity = severity
                    )
                )
            }
        } catch (e: Exception) {
            // Log error
            e.printStackTrace()
        }

        return@withContext threats
    }

    // Scan network for devices
    suspend fun scanNetwork(): List<Device> = withContext(Dispatchers.IO) {
        val devices = mutableListOf<Device>()

        try {
            val scannedDevices = networkScanner.scanNetwork()

            // Convert scanned devices to our Device model
            scannedDevices.forEach { scannedDevice ->
                val deviceType = when {
                    scannedDevice.isIoTDevice -> DeviceType.IOT
                    scannedDevice.deviceName.contains("router", ignoreCase = true) -> DeviceType.ROUTER
                    scannedDevice.deviceName.contains("tv", ignoreCase = true) -> DeviceType.SMART_TV
                    scannedDevice.deviceName.contains("phone", ignoreCase = true) -> DeviceType.SMARTPHONE
                    else -> DeviceType.UNKNOWN
                }

                devices.add(
                    Device(
                        id = UUID.randomUUID().toString(),
                        name = scannedDevice.deviceName,
                        ip = scannedDevice.ipAddress,
                        mac = scannedDevice.macAddress,
                        vendor = scannedDevice.manufacturer ?: "Unknown",
                        type = deviceType,
                        isVulnerable = false,
                        vulnerabilityCount = 0
                    )
                )
            }

            // Update cached devices
            cachedDevices = devices
        } catch (e: Exception) {
            // Log error
            e.printStackTrace()
        }

        return@withContext devices
    }

    // Scan device for vulnerabilities
    suspend fun scanDeviceVulnerabilities(deviceId: String): List<Vulnerability> = withContext(Dispatchers.IO) {
        val vulnerabilities = mutableListOf<Vulnerability>()

        try {
            val device = cachedDevices.find { it.id == deviceId }
            if (device != null) {
                // In a real app, this would perform actual vulnerability scanning
                // For now, we'll use mock data based on device type

                when (device.type) {
                    DeviceType.SMARTPHONE -> {
                        // Smartphones typically have fewer vulnerabilities
                    }
                    DeviceType.SMART_TV -> {
                        // Smart TVs might have more vulnerabilities
                        vulnerabilities.add(
                            Vulnerability(
                                id = UUID.randomUUID().toString(),
                                title = "Default Credentials",
                                description = "Device is using default manufacturer credentials for web interface",
                                severity = VulnerabilitySeverity.HIGH,
                                deviceId = deviceId,
                                deviceIp = device.ip,
                                recommendation = "Change default credentials or disable web interface if not needed"
                            )
                        )
                        vulnerabilities.add(
                            Vulnerability(
                                id = UUID.randomUUID().toString(),
                                title = "Outdated Firmware",
                                description = "Device is running an outdated firmware version with known security issues",
                                severity = VulnerabilitySeverity.MEDIUM,
                                deviceId = deviceId,
                                deviceIp = device.ip,
                                recommendation = "Update device firmware to the latest version"
                            )
                        )
                    }
                    DeviceType.ROUTER -> {
                        // Routers might have critical vulnerabilities
                        vulnerabilities.add(
                            Vulnerability(
                                id = UUID.randomUUID().toString(),
                                title = "Telnet Enabled",
                                description = "Telnet service is enabled which transmits data in plaintext",
                                severity = VulnerabilitySeverity.HIGH,
                                deviceId = deviceId,
                                deviceIp = device.ip,
                                recommendation = "Disable Telnet and use SSH instead"
                            )
                        )
                        vulnerabilities.add(
                            Vulnerability(
                                id = UUID.randomUUID().toString(),
                                title = "Weak Admin Password",
                                description = "Router is using a weak or default admin password",
                                severity = VulnerabilitySeverity.CRITICAL,
                                deviceId = deviceId,
                                deviceIp = device.ip,
                                recommendation = "Change the admin password to a strong, unique password"
                            )
                        )
                    }
                    DeviceType.IOT -> {
                        // IoT devices often have many vulnerabilities
                        vulnerabilities.add(
                            Vulnerability(
                                id = UUID.randomUUID().toString(),
                                title = "Unencrypted Communication",
                                description = "Device is communicating with cloud services without encryption",
                                severity = VulnerabilitySeverity.HIGH,
                                deviceId = deviceId,
                                deviceIp = device.ip,
                                recommendation = "Check if firmware updates are available to enable encryption"
                            )
                        )
                        vulnerabilities.add(
                            Vulnerability(
                                id = UUID.randomUUID().toString(),
                                title = "No Authentication",
                                description = "Device web interface has no authentication",
                                severity = VulnerabilitySeverity.CRITICAL,
                                deviceId = deviceId,
                                deviceIp = device.ip,
                                recommendation = "Enable authentication or restrict access to the device"
                            )
                        )
                    }
                    else -> {
                        // Unknown devices might have generic vulnerabilities
                        vulnerabilities.add(
                            Vulnerability(
                                id = UUID.randomUUID().toString(),
                                title = "Unknown Services",
                                description = "Device is running unknown services on ports 8080 and 9000",
                                severity = VulnerabilitySeverity.MEDIUM,
                                deviceId = deviceId,
                                deviceIp = device.ip,
                                recommendation = "Investigate services running on these ports"
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            // Log error
            e.printStackTrace()
        }

        return@withContext vulnerabilities
    }

    // Save scan result
    suspend fun saveScanResult(result: ScanResult) = withContext(Dispatchers.IO) {
        // In a real app, this would save to a database
        cachedScanResults[result.id] = result

        // Update last scan time
        lastScanTime = System.currentTimeMillis()

        // Add scan activity
        val activityType = ActivityType.SCAN_COMPLETED
        val activityStatus = if (result.threatsFound > 0 || result.vulnerabilitiesFound > 0) {
            SecurityStatus.WARNING
        } else {
            SecurityStatus.SECURE
        }

        val activityTitle = "${result.scanType.displayName} scan completed"
        val activityDescription = if (result.threatsFound > 0 || result.vulnerabilitiesFound > 0) {
            "${result.threatsFound} threats and ${result.vulnerabilitiesFound} vulnerabilities found"
        } else {
            "No issues detected"
        }

        val newActivity = NetworkActivity(
            type = activityType,
            title = activityTitle,
            description = activityDescription,
            timestamp = lastScanTime,
            status = activityStatus
        )

        cachedActivities.add(0, newActivity)

        // Keep only the last 20 activities
        if (cachedActivities.size > 20) {
            cachedActivities = cachedActivities.take(20).toMutableList()
        }
    }

    // Generate report
    suspend fun generateReport(scanResultId: String): String = withContext(Dispatchers.IO) {
        // In a real app, this would generate a PDF report
        val reportId = UUID.randomUUID().toString()

        // Add report generation activity
        val activityType = ActivityType.REPORT_GENERATED
        val activityStatus = SecurityStatus.SECURE

        val activityTitle = "Security report generated"
        val activityDescription = "Report ID: $reportId"

        val newActivity = NetworkActivity(
            type = activityType,
            title = activityTitle,
            description = activityDescription,
            timestamp = System.currentTimeMillis(),
            status = activityStatus
        )

        cachedActivities.add(0, newActivity)

        // Keep only the last 20 activities
        if (cachedActivities.size > 20) {
            cachedActivities = cachedActivities.take(20).toMutableList()
        }

        return@withContext reportId
    }

    // Perform ARP spoofing scan
    private fun performArpSpoofingScan(): Flow<ScanProgress> = flow {
        emit(ScanProgress(0, "Initializing ARP spoofing scan..."))
        delay(500)

        emit(ScanProgress(20, "Analyzing ARP tables..."))
        delay(1000)

        emit(ScanProgress(50, "Checking for suspicious ARP entries..."))
        val threats = detectArpSpoofing()
        delay(1000)

        emit(ScanProgress(80, "Processing results..."))
        delay(500)

        emit(ScanProgress(
            progress = 100,
            message = "ARP spoofing scan completed",
            devices = emptyList(),
            threats = threats,
            vulnerabilities = emptyList()
        ))
    }.flowOn(Dispatchers.IO)

    // Perform DNS spoofing scan
    private fun performDnsSpoofingScan(): Flow<ScanProgress> = flow {
        emit(ScanProgress(0, "Initializing DNS spoofing scan..."))
        delay(500)

        emit(ScanProgress(20, "Resolving common domains..."))
        delay(1000)

        emit(ScanProgress(50, "Comparing with trusted DNS servers..."))
        val threats = detectDnsSpoofing()
        delay(1000)

        emit(ScanProgress(80, "Processing results..."))
        delay(500)

        emit(ScanProgress(
            progress = 100,
            message = "DNS spoofing scan completed",
            devices = emptyList(),
            threats = threats,
            vulnerabilities = emptyList()
        ))
    }.flowOn(Dispatchers.IO)

    // Perform vulnerability scan
    private fun performVulnerabilityScan(): Flow<ScanProgress> = flow {
        emit(ScanProgress(0, "Initializing vulnerability scan..."))
        delay(500)

        emit(ScanProgress(20, "Discovering devices..."))
        val devices = scanNetwork()
        delay(1000)

        emit(ScanProgress(50, "Scanning for vulnerabilities..."))
        val vulnerabilities = mutableListOf<Vulnerability>()
        devices.forEach { device ->
            val deviceVulnerabilities = scanDeviceVulnerabilities(device.id)
            vulnerabilities.addAll(deviceVulnerabilities)
        }
        delay(1000)

        emit(ScanProgress(80, "Processing results..."))
        delay(500)

        emit(ScanProgress(
            progress = 100,
            message = "Vulnerability scan completed",
            devices = devices,
            threats = emptyList(),
            vulnerabilities = vulnerabilities
        ))
    }.flowOn(Dispatchers.IO)

    // Perform vulnerability scan for a specific device
    private fun performVulnerabilityScan(deviceId: String): Flow<ScanProgress> = flow {
        emit(ScanProgress(0, "Initializing vulnerability scan..."))
        delay(500)

        emit(ScanProgress(30, "Scanning device ports..."))
        delay(1000)

        emit(ScanProgress(60, "Checking for vulnerabilities..."))
        val vulnerabilities = scanDeviceVulnerabilities(deviceId)
        delay(1000)

        emit(ScanProgress(80, "Processing results..."))
        delay(500)

        emit(ScanProgress(
            progress = 100,
            message = "Vulnerability scan completed",
            devices = emptyList(),
            threats = emptyList(),
            vulnerabilities = vulnerabilities
        ))
    }.flowOn(Dispatchers.IO)

    // Perform comprehensive scan
    private fun performComprehensiveScan(): Flow<ScanProgress> = flow {
        emit(ScanProgress(0, "Initializing comprehensive scan..."))
        delay(500)

        emit(ScanProgress(10, "Discovering devices..."))
        val devices = scanNetwork()
        delay(1000)

        emit(ScanProgress(30, "Checking for ARP spoofing..."))
        val arpThreats = detectArpSpoofing()
        delay(1000)

        emit(ScanProgress(50, "Checking for DNS spoofing..."))
        val dnsThreats = detectDnsSpoofing()
        delay(1000)

        emit(ScanProgress(70, "Scanning for vulnerabilities..."))
        val vulnerabilities = mutableListOf<Vulnerability>()
        devices.forEach { device ->
            val deviceVulnerabilities = scanDeviceVulnerabilities(device.id)
            vulnerabilities.addAll(deviceVulnerabilities)
        }
        delay(1000)

        emit(ScanProgress(90, "Processing results..."))
        delay(500)

        val allThreats = mutableListOf<Threat>()
        allThreats.addAll(arpThreats)
        allThreats.addAll(dnsThreats)

        emit(ScanProgress(
            progress = 100,
            message = "Comprehensive scan completed",
            devices = devices,
            threats = allThreats,
            vulnerabilities = vulnerabilities
        ))
    }.flowOn(Dispatchers.IO)

    // Update cache with scan results
    private fun updateCacheWithScanResults(progress: ScanProgress, scanType: ScanType) {
        lastScanTime = System.currentTimeMillis()

        // Update devices if we have new ones
        if (progress.devices.isNotEmpty()) {
            cachedDevices = progress.devices.toMutableList()
        }

        // Update threats
        if (progress.threats.isNotEmpty()) {
            cachedThreats = progress.threats.toMutableList()
        }

        // Add scan activity
        val activityType = ActivityType.SCAN_COMPLETED

        val activityStatus = if (progress.threats.isEmpty() && progress.vulnerabilities.isEmpty()) {
            SecurityStatus.SECURE
        } else {
            SecurityStatus.DANGER
        }

        val activityTitle = "${scanType.displayName} scan completed"

        val activityDescription = if (progress.threats.isEmpty() && progress.vulnerabilities.isEmpty()) {
            "No issues detected"
        } else {
            "${progress.threats.size} threats and ${progress.vulnerabilities.size} vulnerabilities detected"
        }

        val newActivity = NetworkActivity(
            type = activityType,
            title = activityTitle,
            description = activityDescription,
            timestamp = lastScanTime,
            status = activityStatus
        )

        cachedActivities.add(0, newActivity)

        // Keep only the last 20 activities
        if (cachedActivities.size > 20) {
            cachedActivities = cachedActivities.take(20).toMutableList()
        }
    }
}
