package com.cybersec.netspoof.repo

enum class ScanType(var displayName: String) {
    ARP_SPOOFING("ARP Spoofing"),
    DNS_SPOOFING("DNS Spoofing"),
    VULNERABILITY("Vulnerability"),
    COMPREHENSIVE("Comprehensive")
}