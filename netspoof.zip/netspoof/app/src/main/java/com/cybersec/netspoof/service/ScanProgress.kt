package com.cybersec.netspoof.service

import com.cybersec.netspoof.model.Device
import com.cybersec.netspoof.model.Threat
import com.cybersec.netspoof.model.Vulnerability

data class ScanProgress(
    val progress: Int,
    val message: String,
    val devices: List<Device> = emptyList(),
    val threats: List<Threat> = emptyList(),
    val vulnerabilities: List<Vulnerability> = emptyList()
)
