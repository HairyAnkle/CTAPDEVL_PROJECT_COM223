package com.cybersec.netspoof.service

import android.content.Context
import com.cybersec.netspoof.model.*
import com.cybersec.netspoof.utils.ArpSpoofDetector
import com.cybersec.netspoof.utils.DnsSpoofDetector
import com.cybersec.netspoof.utils.NetworkScanner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.util.*

class ScanService(context: Context) {
    private val arpSpoofDetector = ArpSpoofDetector(context)
    private val dnsSpoofDetector = DnsSpoofDetector(context)
    private val networkScanner = NetworkScanner(context)

    // Perform a comprehensive scan
    fun performComprehensiveScan(): Flow<ScanProgress> = flow {
        emit(ScanProgress(0, "Initializing scan..."))

        // Step 1: Scan for devices
        emit(ScanProgress(10, "Scanning for devices..."))
        val devices = networkScanner.scanNetwork()
        emit(ScanProgress(40, "Found ${devices.size} devices"))

        // Step 2: Check for ARP spoofing
        emit(ScanProgress(50, "Checking for ARP spoofing..."))
        val arpThreats = arpSpoofDetector.detectArpSpoofing()
        emit(ScanProgress(70, "ARP spoofing check complete"))

        // Step 3: Check for DNS spoofing
        emit(ScanProgress(80, "Checking for DNS spoofing..."))
        val dnsThreats = dnsSpoofDetector.detectDnsSpoofing()
        emit(ScanProgress(90, "DNS spoofing check complete"))

        // Step 4: Process results
        emit(ScanProgress(95, "Processing results..."))
        val threats = processThreats(arpThreats, dnsThreats)
        val mappedDevices = mapDevices(devices)

        // Complete
        emit(ScanProgress(100, "Scan complete", mappedDevices, threats))
    }.flowOn(Dispatchers.IO)

    // Perform ARP spoofing detection only
    fun performArpSpoofingScan(): Flow<ScanProgress> = flow {
        emit(ScanProgress(0, "Initializing ARP scan..."))
        emit(ScanProgress(50, "Checking for ARP spoofing..."))

        val arpThreats = arpSpoofDetector.detectArpSpoofing()
        val threats = processThreats(arpThreats, emptyList())

        emit(ScanProgress(100, "ARP scan complete", threats = threats))
    }.flowOn(Dispatchers.IO)

    // Perform DNS spoofing detection only
    fun performDnsSpoofingScan(): Flow<ScanProgress> = flow {
        emit(ScanProgress(0, "Initializing DNS scan..."))
        emit(ScanProgress(50, "Checking for DNS spoofing..."))

        val dnsThreats = dnsSpoofDetector.detectDnsSpoofing()
        val threats = processThreats(emptyList(), dnsThreats)

        emit(ScanProgress(100, "DNS scan complete", threats = threats))
    }.flowOn(Dispatchers.IO)

    // Perform vulnerability scan
    fun performVulnerabilityScan(deviceId: String? = null): Flow<ScanProgress> = flow {
        emit(ScanProgress(0, "Initializing vulnerability scan..."))
        emit(ScanProgress(30, "Scanning for devices..."))

        val devices = networkScanner.scanNetwork()
        emit(ScanProgress(60, "Analyzing vulnerabilities..."))

        val vulnerabilities = findVulnerabilities(devices, deviceId)
        val mappedDevices = if (deviceId == null) mapDevices(devices) else emptyList()

        emit(ScanProgress(100, "Vulnerability scan complete", mappedDevices, vulnerabilities = vulnerabilities))
    }.flowOn(Dispatchers.IO)

    // Process threats from ARP and DNS scans
    private fun processThreats(arpThreats: List<String>, dnsThreats: List<String>): List<Threat> {
        val threats = mutableListOf<Threat>()

        // Process ARP spoofing threats
        arpThreats.forEach { threatDesc ->
            val deviceInfo = extractDeviceInfo(threatDesc)
            threats.add(
                Threat(
                    type = ThreatType.ARP_SPOOFING,
                    title = "ARP Spoofing Detected",
                    description = threatDesc,
                    deviceIp = deviceInfo.first,
                    deviceMac = deviceInfo.second,
                    severity = ThreatSeverity.HIGH
                )
            )
        }

        // Process DNS spoofing threats
        dnsThreats.forEach { threatDesc ->
            threats.add(
                Threat(
                    type = ThreatType.DNS_SPOOFING,
                    title = "DNS Spoofing Detected",
                    description = threatDesc,
                    severity = ThreatSeverity.HIGH
                )
            )
        }

        return threats
    }

    // Extract IP and MAC from threat description
    private fun extractDeviceInfo(threatDesc: String): Pair<String?, String?> {
        var ip: String? = null
        var mac: String? = null

        // Extract IP address using regex
        val ipRegex = Regex("\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b")
        val ipMatches = ipRegex.findAll(threatDesc)
        if (ipMatches.count() > 0) {
            ip = ipMatches.first().value
        }

        // Extract MAC address using regex
        val macRegex = Regex("([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})")
        val macMatches = macRegex.findAll(threatDesc)
        if (macMatches.count() > 0) {
            mac = macMatches.first().value
        }

        return Pair(ip, mac)
    }

    // Map NetworkScanner devices to our Device model
    private fun mapDevices(scannerDevices: List<com.cybersec.netspoof.data.entities.Device>): List<Device> {
        return scannerDevices.map { scannerDevice ->
            Device(
                id = UUID.randomUUID().toString(),
                name = scannerDevice.deviceName.takeIf { it != "Unknown" } ?: "Device ${scannerDevice.ipAddress.split(".").last()}",
                ip = scannerDevice.ipAddress,
                mac = scannerDevice.macAddress,
                vendor = scannerDevice.manufacturer ?: "Unknown",
                type = mapDeviceType(scannerDevice.deviceType, scannerDevice.isIoTDevice),
                isVulnerable = scannerDevice.openPorts.isNotEmpty(),
                vulnerabilityCount = calculateVulnerabilityCount(scannerDevice),
                lastSeen = scannerDevice.lastSeen.time,
                isOnline = scannerDevice.isOnline
            )
        }
    }

    // Map device type string to our DeviceType enum
    private fun mapDeviceType(typeString: String, isIoT: Boolean): DeviceType {
        return when {
            isIoT -> DeviceType.IOT_DEVICE
            typeString.contains("router", ignoreCase = true) -> DeviceType.ROUTER
            else -> DeviceType.UNKNOWN
        }
    }

    // Calculate vulnerability count based on open ports
    private fun calculateVulnerabilityCount(device: com.cybersec.netspoof.data.entities.Device): Int {
        var count = 0

        // Count vulnerable ports
        if (device.openPorts.contains(23)) count++ // Telnet
        if (device.openPorts.contains(21)) count++ // FTP
        if (device.openPorts.contains(22) && device.isIoTDevice) count++ // SSH on IoT
        if (device.openPorts.contains(80) && device.isIoTDevice) count++ // HTTP on IoT

        return count
    }

    // Find vulnerabilities in devices
    private fun findVulnerabilities(devices: List<com.cybersec.netspoof.data.entities.Device>, deviceId: String?): List<Vulnerability> {
        val vulnerabilities = mutableListOf<Vulnerability>()

        devices.forEach { device ->
            // Skip if we're looking for a specific device and this isn't it
            if (deviceId != null && !device.ipAddress.endsWith(deviceId.split("-").last())) {
                return@forEach
            }

            // Check for Telnet
            if (device.openPorts.contains(23)) {
                vulnerabilities.add(
                    Vulnerability(
                        title = "Telnet Enabled",
                        description = "Device ${device.ipAddress} has Telnet service enabled which transmits data in plaintext",
                        severity = VulnerabilitySeverity.HIGH,
                        deviceId = deviceId ?: "device-${device.ipAddress.split(".").last()}",
                        recommendation = "Disable Telnet and use SSH instead",
                        id = TODO(),
                        deviceIp = TODO(),
                        cveId = TODO()
                    )
                )
            }

            // Check for FTP
            if (device.openPorts.contains(21)) {
                vulnerabilities.add(
                    Vulnerability(
                        title = "FTP Enabled",
                        description = "Device ${device.ipAddress} has FTP service enabled which may transmit credentials in plaintext",
                        severity = VulnerabilitySeverity.MEDIUM,
                        deviceId = deviceId ?: "device-${device.ipAddress.split(".").last()}",
                        recommendation = "Use SFTP or disable FTP if not needed",
                        id = TODO(),
                        deviceIp = TODO(),
                        cveId = TODO()
                    )
                )
            }

            // Check for HTTP on IoT
            if (device.openPorts.contains(80) && device.isIoTDevice) {
                vulnerabilities.add(
                    Vulnerability(
                        title = "Insecure Web Interface",
                        description = "IoT device ${device.ipAddress} has an unencrypted web interface",
                        severity = VulnerabilitySeverity.MEDIUM,
                        deviceId = deviceId ?: "device-${device.ipAddress.split(".").last()}",
                        recommendation = "Configure the device to use HTTPS instead of HTTP",
                        id = TODO(),
                        deviceIp = TODO(),
                        cveId = TODO()
                    )
                )
            }
        }

        return vulnerabilities
    }
}

// Class to track scan progress and results
data class ScanProgress(
    val progress: Int,
    val message: String,
    val devices: List<Device> = emptyList(),
    val threats: List<Threat> = emptyList(),
    val vulnerabilities: List<Vulnerability> = emptyList()
)
