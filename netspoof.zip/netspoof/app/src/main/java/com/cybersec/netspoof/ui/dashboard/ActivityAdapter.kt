package com.cybersec.netspoof.ui.dashboard

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.cybersec.netspoof.R
import com.cybersec.netspoof.model.NetworkActivity
import com.cybersec.netspoof.model.SecurityStatus
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ActivityAdapter :
    ListAdapter<NetworkActivity, ActivityAdapter.ActivityViewHolder>(ActivityDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ActivityViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_activity, parent, false)
        return ActivityViewHolder(view)
    }

    override fun onBindViewHolder(holder: ActivityViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class ActivityViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val activityIndicator: View = itemView.findViewById(R.id.activity_indicator)
        private val activityTitle: TextView = itemView.findViewById(R.id.activity_title)
        private val activityDescription: TextView = itemView.findViewById(R.id.activity_description)
        private val activityTime: TextView = itemView.findViewById(R.id.activity_time)

        fun bind(activity: NetworkActivity) {
            activityTitle.text = activity.title
            activityDescription.text = activity.description

            // Format time
            val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
            val timeString = timeFormat.format(Date(activity.timestamp))
            activityTime.text = timeString

            // Set indicator color based on status
            val indicatorRes = when (activity.status) {
                SecurityStatus.SECURE -> R.drawable.status_safe_background
                SecurityStatus.WARNING -> R.drawable.status_warning_background
                SecurityStatus.DANGER -> R.drawable.status_danger_background
            }
            activityIndicator.setBackgroundResource(indicatorRes)
        }
    }

    class ActivityDiffCallback : DiffUtil.ItemCallback<NetworkActivity>() {
        override fun areItemsTheSame(oldItem: NetworkActivity, newItem: NetworkActivity): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: NetworkActivity, newItem: NetworkActivity): Boolean {
            return oldItem == newItem
        }
    }
}
