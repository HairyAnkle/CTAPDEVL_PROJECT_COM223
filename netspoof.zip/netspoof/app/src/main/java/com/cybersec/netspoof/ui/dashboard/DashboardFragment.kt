package com.cybersec.netspoof.ui.dashboard

import androidx.fragment.app.viewModels
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.cybersec.netspoof.R
import com.cybersec.netspoof.databinding.FragmentDashboardBinding
import com.cybersec.netspoof.model.Device
import com.cybersec.netspoof.model.SecurityStatus
import com.cybersec.netspoof.viewmodel.DashboardViewModel

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    private lateinit var deviceAdapter: DeviceAdapter
    private lateinit var threatAdapter: ThreatAdapter
    private lateinit var activityAdapter: ActivityAdapter
    private lateinit var viewModel: DashboardViewModel


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // Initialize ViewModel
        viewModel = ViewModelProvider(this)[DashboardViewModel::class.java]

        // Set up adapters
        setupAdapters()

        // Set up click listeners
        setupClickListeners()

        // Observe ViewModel
        observeViewModel()
    }

    private fun setupAdapters() {
        // Device adapter
        deviceAdapter = DeviceAdapter { device ->
            // Navigate to device details
            onDeviceClicked(device)
        }
        binding.devicesRecyclerView.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = deviceAdapter
        }

        // Threat adapter
        threatAdapter = ThreatAdapter { threat ->
            // Show threat details dialog
            Toast.makeText(context, "Threat: ${threat.title}", Toast.LENGTH_SHORT).show()
        }
        binding.threatsRecyclerView.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = threatAdapter
        }

        // Activity adapter
        activityAdapter = ActivityAdapter()
        binding.activitiesRecyclerView.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = activityAdapter
        }
    }

    private fun setupClickListeners() {
        // Start scan button
        binding.startScanButton.setOnClickListener {
            viewModel.startNetworkScan()
        }

        // View all threats
        binding.viewAllThreats.setOnClickListener {
            // Navigate to threats screen or show dialog
            Toast.makeText(context, "View all threats", Toast.LENGTH_SHORT).show()
        }

        // View all devices
        binding.viewAllDevices.setOnClickListener {
            findNavController().navigate(R.id.navigation_devices)
        }
    }

    private fun observeViewModel() {
        // Observe network status
        viewModel.networkStatus.observe(viewLifecycleOwner) { status ->
            // Update status indicator
            val indicatorRes = when (status.status) {
                SecurityStatus.SECURE -> R.drawable.status_safe_background
                SecurityStatus.WARNING -> R.drawable.status_warning_background
                SecurityStatus.DANGER -> R.drawable.status_danger_background
            }
            binding.statusIndicator.setBackgroundResource(indicatorRes)

            // Update status text
            val statusText = when (status.status) {
                SecurityStatus.SECURE -> getString(R.string.network_secure)
                SecurityStatus.WARNING -> getString(R.string.network_warning)
                SecurityStatus.DANGER -> getString(R.string.network_danger)
            }
            binding.statusText.text = statusText

            // Update status text color
            val statusColor = when (status.status) {
                SecurityStatus.SECURE -> R.color.status_safe
                SecurityStatus.WARNING -> R.color.status_warning
                SecurityStatus.DANGER -> R.color.status_danger
            }
            binding.statusText.setTextColor(resources.getColor(statusColor, null))

            // Update description
            binding.statusDescription.text = status.description
        }

        // Observe active threats
        viewModel.activeThreats.observe(viewLifecycleOwner) { threats ->
            if (threats.isEmpty()) {
                binding.noThreatsText.visibility = View.VISIBLE
                binding.threatsRecyclerView.visibility = View.GONE
            } else {
                binding.noThreatsText.visibility = View.GONE
                binding.threatsRecyclerView.visibility = View.VISIBLE
                threatAdapter.submitList(threats)
            }
        }

        // Observe connected devices
        viewModel.connectedDevices.observe(viewLifecycleOwner) { devices ->
            deviceAdapter.submitList(devices)
        }

        // Observe recent activities
        viewModel.recentActivities.observe(viewLifecycleOwner) { activities ->
            activityAdapter.submitList(activities)
        }

        // Observe scanning state
        viewModel.isScanning.observe(viewLifecycleOwner) { isScanning ->
            if (isScanning) {
                binding.startScanButton.isEnabled = false
                binding.startScanButton.text = getString(R.string.scan_in_progress)
            } else {
                binding.startScanButton.isEnabled = true
                binding.startScanButton.text = getString(R.string.start_scan)
            }
        }

        // Observe errors
        viewModel.error.observe(viewLifecycleOwner) { error ->
            error?.let {
                Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
                viewModel.clearError()
            }
        }
    }

    private fun onDeviceClicked(device: Device) {
        // Create a bundle with the deviceId
        val bundle = Bundle().apply {
            putString("deviceId", device.id)
        }

        // Navigate to the device detail fragment with the bundle
        findNavController().navigate(R.id.action_navigation_dashboard_to_deviceDetailFragment, bundle)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}