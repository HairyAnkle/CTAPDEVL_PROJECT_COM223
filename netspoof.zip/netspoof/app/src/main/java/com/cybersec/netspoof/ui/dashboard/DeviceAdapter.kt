package com.cybersec.netspoof.ui.dashboard

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.cybersec.netspoof.R
import com.cybersec.netspoof.model.Device
import com.cybersec.netspoof.model.DeviceType

class DeviceAdapter(private val onDeviceClick: (Device) -> Unit) :
    ListAdapter<Device, DeviceAdapter.DeviceViewHolder>(DeviceDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DeviceViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_device, parent, false)
        return DeviceViewHolder(view, onDeviceClick)
    }

    override fun onBindViewHolder(holder: DeviceViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class DeviceViewHolder(
        itemView: View,
        private val onDeviceClick: (Device) -> Unit
    ) : RecyclerView.ViewHolder(itemView) {
        private val deviceIcon: ImageView = itemView.findViewById(R.id.device_icon)
        private val deviceName: TextView = itemView.findViewById(R.id.device_name)
        private val deviceIp: TextView = itemView.findViewById(R.id.device_ip)
        private val statusIndicator: View = itemView.findViewById(R.id.device_status_indicator)

        fun bind(device: Device) {
            deviceName.text = device.name
            deviceIp.text = device.ip

            // Set device icon based on type
            val iconRes = when (device.type) {
                DeviceType.SMARTPHONE -> R.drawable.ic_device
                DeviceType.TABLET -> R.drawable.ic_device
                DeviceType.LAPTOP -> R.drawable.ic_device
                DeviceType.DESKTOP -> R.drawable.ic_device
                DeviceType.SMART_TV -> R.drawable.ic_device
                DeviceType.GAME_CONSOLE -> R.drawable.ic_device
                DeviceType.IOT_DEVICE -> R.drawable.ic_device
                DeviceType.ROUTER -> R.drawable.ic_router
                DeviceType.UNKNOWN -> R.drawable.ic_device
                DeviceType.IOT -> R.drawable.ic_device
            }
            deviceIcon.setImageResource(iconRes)

            // Set status indicator color
            val statusRes = if (device.isVulnerable) {
                R.drawable.status_warning_background
            } else {
                R.drawable.status_safe_background
            }
            statusIndicator.setBackgroundResource(statusRes)

            // Set click listener
            itemView.setOnClickListener { onDeviceClick(device) }
        }
    }

    class DeviceDiffCallback : DiffUtil.ItemCallback<Device>() {
        override fun areItemsTheSame(oldItem: Device, newItem: Device): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Device, newItem: Device): Boolean {
            return oldItem == newItem
        }
    }
}
