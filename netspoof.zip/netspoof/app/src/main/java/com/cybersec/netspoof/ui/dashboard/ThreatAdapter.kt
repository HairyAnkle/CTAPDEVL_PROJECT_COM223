package com.cybersec.netspoof.ui.dashboard

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.cybersec.netspoof.R
import com.cybersec.netspoof.model.Threat
import com.cybersec.netspoof.model.ThreatType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ThreatAdapter(private val onThreatClick: (Threat) -> Unit) :
    ListAdapter<Threat, ThreatAdapter.ThreatViewHolder>(ThreatDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ThreatViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_threat, parent, false)
        return ThreatViewHolder(view, onThreatClick)
    }

    override fun onBindViewHolder(holder: ThreatViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class ThreatViewHolder(
        itemView: View,
        private val onThreatClick: (Threat) -> Unit
    ) : RecyclerView.ViewHolder(itemView) {
        private val threatIcon: ImageView = itemView.findViewById(R.id.threat_icon)
        private val threatTitle: TextView = itemView.findViewById(R.id.threat_title)
        private val threatDescription: TextView = itemView.findViewById(R.id.threat_description)
        private val threatTime: TextView = itemView.findViewById(R.id.threat_time)
        private val threatMore: ImageView = itemView.findViewById(R.id.threat_more)

        fun bind(threat: Threat) {
            threatTitle.text = threat.title
            threatDescription.text = threat.description

            // Format time
            val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
            val timeString = timeFormat.format(Date(threat.timestamp))
            threatTime.text = timeString

            // Set icon based on threat type
            val iconRes = when (threat.type) {
                ThreatType.ARP_SPOOFING -> R.drawable.ic_warning
                ThreatType.DNS_SPOOFING -> R.drawable.ic_warning
                ThreatType.ROGUE_DEVICE -> R.drawable.ic_warning
                ThreatType.MAN_IN_THE_MIDDLE -> R.drawable.ic_warning
                ThreatType.VULNERABILITY -> R.drawable.ic_warning
            }
            threatIcon.setImageResource(iconRes)

            // Set click listeners
            itemView.setOnClickListener { onThreatClick(threat) }
            threatMore.setOnClickListener { onThreatClick(threat) }
        }
    }

    class ThreatDiffCallback : DiffUtil.ItemCallback<Threat>() {
        override fun areItemsTheSame(oldItem: Threat, newItem: Threat): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Threat, newItem: Threat): Boolean {
            return oldItem == newItem
        }
    }
}
