package com.cybersec.netspoof.ui.devices

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import com.cybersec.netspoof.R
import com.cybersec.netspoof.databinding.FragmentDeviceDetailBinding
import com.cybersec.netspoof.model.DeviceType
import com.cybersec.netspoof.viewmodel.devicedetail.DeviceDetailViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DeviceDetailFragment : Fragment() {

    private var _binding: FragmentDeviceDetailBinding? = null
    private val binding get() = _binding!!

    private lateinit var viewModel: DeviceDetailViewModel
    private lateinit var portAdapter: PortAdapter
    private lateinit var vulnerabilityAdapter: VulnerabilityAdapter

    private var deviceId: String = ""

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDeviceDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Get deviceId from arguments bundle instead of using Safe Args
        arguments?.let {
            deviceId = it.getString("deviceId", "")
        }

        // Initialize ViewModel
        viewModel = ViewModelProvider(this, ViewModelProvider.AndroidViewModelFactory(requireActivity().application))[DeviceDetailViewModel::class.java]

        // Set up toolbar
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }

        // Set up adapters
        setupAdapters()

        // Set up click listeners
        setupClickListeners()

        // Load device details
        viewModel.loadDeviceDetails(deviceId)

        // Observe ViewModel
        observeViewModel()
    }

    private fun setupAdapters() {
        // Port adapter
        portAdapter = PortAdapter()
        binding.portsRecyclerView.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = portAdapter
        }

        // Vulnerability adapter
        vulnerabilityAdapter = VulnerabilityAdapter()
        binding.vulnerabilitiesRecyclerView.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = vulnerabilityAdapter
        }
    }

    private fun setupClickListeners() {
        // Port scan button
        binding.portScanButton.setOnClickListener {
            viewModel.startPortScan(deviceId)
        }

        // Vulnerability scan button
        binding.vulnerabilityScanButton.setOnClickListener {
            viewModel.startVulnerabilityScan(deviceId)
        }
    }

    private fun observeViewModel() {
        // Observe device details
        viewModel.device.observe(viewLifecycleOwner) { device ->
            device?.let {
                // Set device name and vendor
                binding.deviceName.text = it.name
                binding.deviceVendor.text = it.vendor

                // Set device IP and MAC
                binding.deviceIp.text = it.ip
                binding.deviceMac.text = it.mac

                // Set last seen time
                val dateFormat = SimpleDateFormat("MMM d, yyyy h:mm a", Locale.getDefault())
                val lastSeenText = if (it.isOnline) {
                    "Online"
                } else {
                    dateFormat.format(Date(it.lastSeen))
                }
                binding.deviceLastSeen.text = lastSeenText

                // Set device icon based on type
                val iconRes = when (it.type) {
                    DeviceType.SMARTPHONE -> R.drawable.ic_device
                    DeviceType.TABLET -> R.drawable.ic_device
                    DeviceType.LAPTOP -> R.drawable.ic_device
                    DeviceType.DESKTOP -> R.drawable.ic_device
                    DeviceType.SMART_TV -> R.drawable.ic_device
                    DeviceType.GAME_CONSOLE -> R.drawable.ic_device
                    DeviceType.IOT_DEVICE -> R.drawable.ic_device
                    DeviceType.ROUTER -> R.drawable.ic_router
                    DeviceType.UNKNOWN -> R.drawable.ic_device
                    DeviceType.IOT -> R.drawable.ic_device
                }
                binding.deviceIcon.setImageResource(iconRes)

                // Set status indicator
                val statusRes = if (it.isVulnerable) {
                    R.drawable.status_warning_background
                } else {
                    R.drawable.status_safe_background
                }
                binding.deviceStatusIndicator.setBackgroundResource(statusRes)
            }
        }

        // Observe ports
        viewModel.ports.observe(viewLifecycleOwner) { ports ->
            portAdapter.submitList(ports)
        }

        // Observe vulnerabilities
        viewModel.vulnerabilities.observe(viewLifecycleOwner) { vulnerabilities ->
            vulnerabilityAdapter.submitList(vulnerabilities)
        }

        // Observe port scanning state
        viewModel.isPortScanning.observe(viewLifecycleOwner) { isScanning ->
            binding.portScanButton.isEnabled = !isScanning
            binding.portScanButton.text = if (isScanning) {
                "Scanning..."
            } else {
                getString(R.string.port_scan)
            }
        }

        // Observe vulnerability scanning state
        viewModel.isVulnerabilityScanning.observe(viewLifecycleOwner) { isScanning ->
            binding.vulnerabilityScanButton.isEnabled = !isScanning
            binding.vulnerabilityScanButton.text = if (isScanning) {
                "Scanning..."
            } else {
                getString(R.string.vulnerability_scan)
            }
        }

        // Observe errors
        viewModel.error.observe(viewLifecycleOwner) { error ->
            error?.let {
                Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
                viewModel.clearError()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
