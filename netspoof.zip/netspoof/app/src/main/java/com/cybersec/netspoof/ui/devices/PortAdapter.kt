package com.cybersec.netspoof.ui.devices

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.cybersec.netspoof.R
import com.cybersec.netspoof.model.Port
import com.cybersec.netspoof.model.PortStatus

class PortAdapter : ListAdapter<Port, PortAdapter.PortViewHolder>(PortDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PortViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_port, parent, false)
        return PortViewHolder(view)
    }

    override fun onBindViewHolder(holder: PortViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class PortViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val portNumber: TextView = itemView.findViewById(R.id.port_number)
        private val portService: TextView = itemView.findViewById(R.id.port_service)
        private val portStatus: TextView = itemView.findViewById(R.id.port_status)

        fun bind(port: Port) {
            portNumber.text = port.number.toString()
            portService.text = port.service

            // Set status text and color
            portStatus.text = port.status.name
            val statusColor = when (port.status) {
                PortStatus.OPEN -> R.color.status_warning
                PortStatus.CLOSED -> R.color.text_primary
                PortStatus.FILTERED -> R.color.text_secondary
            }
            portStatus.setTextColor(itemView.context.getColor(statusColor))
        }
    }

    class PortDiffCallback : DiffUtil.ItemCallback<Port>() {
        override fun areItemsTheSame(oldItem: Port, newItem: Port): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Port, newItem: Port): Boolean {
            return oldItem == newItem
        }
    }
}
