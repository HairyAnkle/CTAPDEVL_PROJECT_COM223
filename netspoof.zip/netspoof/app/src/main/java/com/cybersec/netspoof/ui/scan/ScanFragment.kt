package com.cybersec.netspoof.ui.scan

import android.animation.ObjectAnimator
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.core.content.ContextCompat
import com.cybersec.netspoof.R
import com.cybersec.netspoof.databinding.FragmentScanBinding
import com.cybersec.netspoof.repo.ScanType
import com.google.android.material.chip.Chip
import com.cybersec.netspoof.model.ScanResultItem
import com.cybersec.netspoof.viewmodel.ScanViewModel
import com.github.mikephil.charting.animation.Easing
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.formatter.PercentFormatter
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class ScanFragment : Fragment() {

    private var _binding: FragmentScanBinding? = null
    private val binding get() = _binding!!

    private lateinit var viewModel: ScanViewModel
    private lateinit var scanResultAdapter: ScanResultAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentScanBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize ViewModel
        viewModel = ViewModelProvider(this)[ScanViewModel::class.java]

        // Set up scan type chip group
        setupScanTypeChips()

        // Set up pie chart
        setupPieChart()

        // Set up scan result adapter
        setupScanResultAdapter()

        // Set up click listeners
        setupClickListeners()

        // Observe ViewModel
        observeViewModel()
    }

    private fun setupScanTypeChips() {
        // Set up chip group listener
        binding.scanTypeChipGroup.setOnCheckedChangeListener { group, checkedId ->
            val chip = group.findViewById<Chip>(checkedId)
            val scanType = when (chip?.id) {
                R.id.chip_arp -> ScanType.ARP_SPOOFING
                R.id.chip_dns -> ScanType.DNS_SPOOFING
                R.id.chip_vulnerability -> ScanType.VULNERABILITY
                R.id.chip_comprehensive -> ScanType.COMPREHENSIVE
                else -> ScanType.COMPREHENSIVE
            }
            viewModel.setSelectedScanType(scanType)
        }

        // Set initial selection
        binding.chipComprehensive.isChecked = true
    }

    private fun setupScanResultAdapter() {
        scanResultAdapter = ScanResultAdapter { resultItem ->
            // Handle result item click
            showResultDetailDialog(resultItem)
        }
    }

    private fun setupClickListeners() {
        // Start scan button
        binding.startScanButton.setOnClickListener {
            viewModel.startScan()
        }

        // Generate report button
        binding.generateReportButton.setOnClickListener {
            viewModel.generateReport()
        }
    }

    private fun setupPieChart() {
        binding.severityChart.apply {
            description.isEnabled = false
            setUsePercentValues(true)
            setExtraOffsets(5f, 10f, 5f, 5f)
            dragDecelerationFrictionCoef = 0.95f
            isDrawHoleEnabled = true
            setHoleColor(Color.TRANSPARENT)
            setTransparentCircleColor(Color.WHITE)
            setTransparentCircleAlpha(110)
            holeRadius = 58f
            transparentCircleRadius = 61f
            setDrawCenterText(true)
            rotationAngle = 0f
            isRotationEnabled = true
            isHighlightPerTapEnabled = true
            animateY(1400, Easing.EaseInOutQuad)

            legend.apply {
                verticalAlignment = Legend.LegendVerticalAlignment.TOP
                horizontalAlignment = Legend.LegendHorizontalAlignment.RIGHT
                orientation = Legend.LegendOrientation.VERTICAL
                setDrawInside(false)
                xEntrySpace = 7f
                yEntrySpace = 0f
                yOffset = 0f
            }
        }
    }

    private fun observeViewModel() {
        // Observe scan progress
        viewModel.scanProgress.observe(viewLifecycleOwner) { progress ->
            updateProgressUI(progress)
        }

        // Observe scan status message
        viewModel.scanStatusMessage.observe(viewLifecycleOwner) { message ->
            binding.scanStatusText.text = message
        }

        // Observe scanning state
        viewModel.isScanning.observe(viewLifecycleOwner) { isScanning ->
            updateScanningUI(isScanning)
        }

        // Observe scan result items
        viewModel.scanResultItems.observe(viewLifecycleOwner) { resultItems ->
            scanResultAdapter.submitList(resultItems)
        }

        // Observe scan statistics
        viewModel.scanStats.observe(viewLifecycleOwner) { stats ->
            updateScanStatistics(stats)
            updatePieChart(stats)
        }

        // Observe scan results
        viewModel.scanResults.observe(viewLifecycleOwner) { result ->
            if (result != null) {
                binding.scanResultsCard.visibility = View.VISIBLE

            } else {
                binding.scanResultsCard.visibility = View.GONE
            }
        }

        // Observe errors
        viewModel.error.observe(viewLifecycleOwner) { error ->
            error?.let {
                Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
                viewModel.clearError()
            }
        }
    }

    private fun updateProgressUI(progress: Int) {
        // Update progress indicator
        binding.scanProgressIndicator.progress = progress

        // Animate progress with ObjectAnimator
        val progressAnimator = ObjectAnimator.ofInt(binding.scanProgressIndicator, "progress", 0, progress)
        progressAnimator.duration = 300
        progressAnimator.interpolator = DecelerateInterpolator()
        progressAnimator.start()
    }

    private fun updateScanningUI(isScanning: Boolean) {
        binding.startScanButton.isEnabled = !isScanning
        binding.scanTypeChipGroup.isEnabled = !isScanning

        if (isScanning) {
            binding.startScanButton.text = getString(R.string.scan_in_progress)
            binding.scanProgressContainer.visibility = View.VISIBLE
            binding.scanResultsCard.visibility = View.GONE
        } else {
            binding.startScanButton.text = getString(R.string.start_scan)
            binding.scanProgressContainer.visibility = View.GONE
        }
    }

    private fun updateScanStatistics(stats: ScanViewModel.ScanStatistics) {
        binding.scanDurationText.text = stats.duration
        binding.threatsFoundText.text = stats.threatsFound.toString()
        binding.vulnerabilitiesFoundText.text = stats.vulnerabilitiesFound.toString()
    }

    private fun updatePieChart(stats: ScanViewModel.ScanStatistics) {
        val entries = ArrayList<PieEntry>()

        if (stats.highSeverityCount > 0) {
            entries.add(PieEntry(stats.highSeverityCount.toFloat(), "High"))
        }

        if (stats.mediumSeverityCount > 0) {
            entries.add(PieEntry(stats.mediumSeverityCount.toFloat(), "Medium"))
        }

        if (stats.lowSeverityCount > 0) {
            entries.add(PieEntry(stats.lowSeverityCount.toFloat(), "Low"))
        }

        val dataSet = PieDataSet(entries, "Severity Levels")
        dataSet.apply {
            sliceSpace = 3f
            selectionShift = 5f

            // Set colors for severity levels
            val colors = ArrayList<Int>()
            colors.add(ContextCompat.getColor(requireContext(), R.color.status_danger))
            colors.add(ContextCompat.getColor(requireContext(), R.color.status_warning))
            colors.add(ContextCompat.getColor(requireContext(), R.color.primary))
            setColors(colors)
        }

        val data = PieData(dataSet)
        data.apply {
            setValueFormatter(PercentFormatter(binding.severityChart))
            setValueTextSize(11f)
            setValueTextColor(Color.WHITE)
        }

        binding.severityChart.apply {
            this.data = data
            highlightValues(null)
            centerText = "Severity\nDistribution"
            invalidate()
        }
    }

    private fun showResultDetailDialog(resultItem: ScanResultItem) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(resultItem.title)
            .setMessage(
                "Device: ${resultItem.deviceInfo}\n\n" +
                        "Description: ${resultItem.description}\n\n" +
                        "Severity: ${resultItem.severity}\n" +
                        "Type: ${resultItem.type}"
            )
            .setPositiveButton("Close", null)
            .setNeutralButton("View Device") { _, _ ->
                // Navigate to device detail
                // TODO: Implement navigation to device detail
            }
            .show()
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
