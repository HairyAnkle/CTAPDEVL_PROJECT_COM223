package com.cybersec.netspoof.ui.scan

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.cybersec.netspoof.model.ScanResultItem
import com.cybersec.netspoof.R

class ScanResultAdapter(
    private val onItemClick: (ScanResultItem) -> Unit
) : ListAdapter<ScanResultItem, ScanResultAdapter.ScanResultViewHolder>(ScanResultDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ScanResultViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_scan_result, parent, false)
        return ScanResultViewHolder(view, onItemClick)
    }

    override fun onBindViewHolder(holder: ScanResultViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class ScanResultViewHolder(
        itemView: View,
        private val onItemClick: (ScanResultItem) -> Unit
    ) : RecyclerView.ViewHolder(itemView) {
        private val resultIcon: ImageView = itemView.findViewById(R.id.result_icon)
        private val resultTitle: TextView = itemView.findViewById(R.id.result_title)
        private val resultDevice: TextView = itemView.findViewById(R.id.result_device)
        private val resultDescription: TextView = itemView.findViewById(R.id.result_description)
        private val resultMore: ImageView = itemView.findViewById(R.id.result_more)

        fun bind(item: ScanResultItem) {
            resultTitle.text = item.title
            resultDevice.text = "Device: ${item.deviceInfo}"
            resultDescription.text = item.description

            // Set icon based on type
            val iconRes = when {
                item.type.contains("THREAT", ignoreCase = true) -> R.drawable.ic_warning
                item.type.contains("VULNERABILITY", ignoreCase = true) -> R.drawable.ic_security
                else -> R.drawable.ic_warning
            }
            resultIcon.setImageResource(iconRes)

            // Set icon tint based on severity
            val tintColor = when {
                item.severity.contains("HIGH", ignoreCase = true) ||
                        item.severity.contains("CRITICAL", ignoreCase = true) ->
                    itemView.context.getColor(R.color.status_danger)
                item.severity.contains("MEDIUM", ignoreCase = true) ->
                    itemView.context.getColor(R.color.status_warning)
                else ->
                    itemView.context.getColor(R.color.primary)
            }
            resultIcon.setColorFilter(tintColor)

            // Set click listeners
            itemView.setOnClickListener {
                onItemClick(item)
            }

            resultMore.setOnClickListener {
                onItemClick(item)
            }
        }

    }

    class ScanResultDiffCallback : DiffUtil.ItemCallback<ScanResultItem>() {
        override fun areItemsTheSame(oldItem: ScanResultItem, newItem: ScanResultItem): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: ScanResultItem, newItem: ScanResultItem): Boolean {
            return oldItem == newItem
        }
    }
}

