package com.cybersec.netspoof.ui.splash.Adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.cybersec.netspoof.R
import com.cybersec.netspoof.ui.splash.SplashFinalFragment
import com.cybersec.netspoof.ui.splash.SplashPageFragment

class SplashPagerAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {
    override fun getItemCount(): Int = 3

    override fun createFragment(position: Int): Fragment {
        return when (position) {
            0 -> SplashPageFragment.Companion.newInstance(R.drawable.app_icon_foreground, "Welcome", "Protect your IoT devices.")
            1 -> SplashPageFragment.Companion.newInstance(R.drawable.app_icon_foreground, "Detect Attacks", "Real-time spoofing detection.")
            else -> SplashFinalFragment()
        }
    }
}