package com.cybersec.netspoof.ui.splash

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.cybersec.netspoof.MainActivity
import com.cybersec.netspoof.ui.splash.Adapter.SplashPagerAdapter
import com.cybersec.netspoof.databinding.ActivitySplashBinding

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySplashBinding
    private lateinit var splashAdapter: SplashPagerAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        splashAdapter = SplashPagerAdapter(this)
        binding.viewPager.adapter = splashAdapter
        binding.dotsIndicator.attachTo(binding.viewPager)

    }

    fun navigateToLogin() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}