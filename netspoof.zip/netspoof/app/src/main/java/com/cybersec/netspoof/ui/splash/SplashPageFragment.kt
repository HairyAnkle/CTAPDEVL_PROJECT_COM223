package com.cybersec.netspoof.ui.splash

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.cybersec.netspoof.R

class SplashPageFragment : Fragment() {
    companion object {
        fun newInstance(imageRes: Int, title: String, desc: String): SplashPageFragment {
            val fragment = SplashPageFragment()
            val args = Bundle()
            args.putInt("imageRes", imageRes)
            args.putString("title", title)
            args.putString("desc", desc)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val view = inflater.inflate(R.layout.fragment_splash_page, container, false)
        view.findViewById<ImageView>(R.id.imageView).setImageResource(requireArguments().getInt("imageRes"))
        view.findViewById<TextView>(R.id.titleText).text = requireArguments().getString("title")
        view.findViewById<TextView>(R.id.descText).text = requireArguments().getString("desc")
        return view
    }
}