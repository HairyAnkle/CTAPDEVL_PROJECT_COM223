package com.cybersec.netspoof.utils

import android.content.Context
import android.net.wifi.WifiManager
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.InetAddress
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap

class ArpSpoofDetector(private val context: Context) {

    private val TAG = "ArpSpoofDetector"

    private val arpCache = ConcurrentHashMap<String, String>() // IP -> MAC
    private val macToIpMapping = ConcurrentHashMap<String, MutableSet<String>>() // MAC -> multiple IPs

    private var gatewayIP: String? = null
    private var gatewayMAC: String? = null
    private var localIPPrefix: String = ""

    init {
        initializeGatewayInfo()
    }

    private fun initializeGatewayInfo() {
        val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val dhcpInfo = wifiManager.dhcpInfo
        val ipAddress = intToIp(dhcpInfo.ipAddress)
        gatewayIP = intToIp(dhcpInfo.gateway)

        localIPPrefix = ipAddress.substringBeforeLast(".") // e.g., 192.168.1
        Log.d(TAG, "Gateway IP: $gatewayIP | IP Prefix: $localIPPrefix")
    }

    private fun intToIp(ip: Int): String {
        return listOf(
            ip and 0xFF,
            ip shr 8 and 0xFF,
            ip shr 16 and 0xFF,
            ip shr 24 and 0xFF
        ).joinToString(".")
    }

    suspend fun detectArpSpoofing(): List<String> = withContext(Dispatchers.IO) {
        val threats = mutableListOf<String>()

        try {
            pingSubnet()

            val currentArp = readArpTable()

            if (arpCache.isEmpty()) {
                initializeCaches(currentArp)
                return@withContext threats
            }

            for ((ip, mac) in currentArp) {
                val normalizedMac = mac.uppercase()
                val ipSet = macToIpMapping.getOrPut(normalizedMac) {
                    Collections.synchronizedSet(mutableSetOf())
                }

                if (ipSet.add(ip) && ipSet.size > 1) {
                    threats.add("⚠️ MAC $normalizedMac associated with multiple IPs: ${ipSet.joinToString()}")
                }

                val previousMac = arpCache[ip]
                if (previousMac != null && previousMac != normalizedMac) {
                    threats.add("🚨 IP $ip MAC changed from $previousMac to $normalizedMac")
                }

                arpCache[ip] = normalizedMac
            }

            if (gatewayIP != null && gatewayMAC != null) {
                for ((ip, mac) in currentArp) {
                    if (ip != gatewayIP && mac.equals(gatewayMAC, ignoreCase = true)) {
                        threats.add("⚠️ Possible gateway spoofing: IP $ip has same MAC as gateway $gatewayIP")
                    }
                }
            }

        } catch (e: Exception) {
            Log.e(TAG, "ARP detection failed", e)
        }

        return@withContext threats
    }

    private suspend fun pingSubnet() = withContext(Dispatchers.IO) {
        for (i in 1..254) {
            val ip = "$localIPPrefix.$i"
            ping(ip)
        }
    }

    private fun ping(ip: String) {
        try {
            val address = InetAddress.getByName(ip)
            if (address.isReachable(250)) {
                Log.d(TAG, "Pinged $ip")
            }
        } catch (e: Exception) {
            // Ignore unreachable IPs
        }
    }

    private fun initializeCaches(currentArp: Map<String, String>) {
        currentArp.forEach { (ip, mac) ->
            val normalizedMac = mac.uppercase()
            arpCache[ip] = normalizedMac
            macToIpMapping.getOrPut(normalizedMac) {
                Collections.synchronizedSet(mutableSetOf())
            }.add(ip)

            if (ip == gatewayIP) {
                gatewayMAC = normalizedMac
                Log.d(TAG, "Gateway detected: $gatewayIP -> $gatewayMAC")
            }
        }
    }

    private fun readArpTable(): Map<String, String> {
        val arpMap = mutableMapOf<String, String>()
        try {
            File("/proc/net/arp").useLines { lines ->
                lines.drop(1).forEach { line ->
                    val parts = line.trim().split(Regex("\\s+"))
                    if (parts.size >= 6) {
                        val ip = parts[0]
                        val flag = parts[2]
                        val mac = parts[3]

                        if (flag == "0x2" && mac.isValidMac()) {
                            arpMap[ip] = mac
                        } else {
                            Log.w(TAG, "Skipping incomplete ARP entry: $ip (flag=$flag)")
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to read ARP table", e)
        }
        return arpMap
    }

    private fun String.isValidMac(): Boolean {
        return matches(Regex("([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}")) && this != "00:00:00:00:00:00"
    }
}
