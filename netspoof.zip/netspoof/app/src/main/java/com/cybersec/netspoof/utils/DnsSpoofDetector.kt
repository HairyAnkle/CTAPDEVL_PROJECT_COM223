package com.cybersec.netspoof.utils

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap

class DnsSpoofDetector(
    private val context: Context,
    private val trustedDnsServers: List<String> = listOf("8.8.8.8", "1.1.1.1")
) {
    private val TAG = "DnsSpoofDetector"
    private val dnsCache = ConcurrentHashMap<String, List<String>>()
    private val commonDomains = listOf(
        "google.com", "facebook.com", "amazon.com", "microsoft.com", "apple.com",
        "youtube.com", "netflix.com", "twitter.com", "instagram.com", "linkedin.com"
    )

    suspend fun detectDnsSpoofing(): List<String> = withContext(Dispatchers.IO) {
        val threats = mutableListOf<String>()
        for (domain in commonDomains) {
            val localIps = resolveDomainLocally(domain)
            val trustedIps = resolveViaTrustedDns(domain, "8.8.8.8")

            if (localIps.isNotEmpty() && trustedIps.isNotEmpty() && localIps != trustedIps) {
                Log.w(TAG, "Potential DNS spoofing detected for $domain: local=$localIps vs trusted=$trustedIps")
                threats.add("DNS spoofing: $domain resolves to $localIps locally, but $trustedIps on 8.8.8.8")
            }

            dnsCache[domain] = localIps
        }
        threats
    }

    private fun resolveDomainLocally(domain: String): List<String> {
        return try {
            InetAddress.getAllByName(domain).map { it.hostAddress }.distinct()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to resolve locally: $domain", e)
            emptyList()
        }
    }

    private fun resolveViaTrustedDns(domain: String, dnsServer: String): List<String> {
        return try {
            val socket = DatagramSocket()
            socket.soTimeout = 3000

            val query = buildDnsQuery(domain)
            val requestPacket = DatagramPacket(query, query.size, InetAddress.getByName(dnsServer), 53)
            socket.send(requestPacket)

            val responseBuffer = ByteArray(512)
            val responsePacket = DatagramPacket(responseBuffer, responseBuffer.size)
            socket.receive(responsePacket)

            parseDnsResponse(responseBuffer)
        } catch (e: Exception) {
            Log.e(TAG, "Trusted DNS resolution failed: $domain", e)
            emptyList()
        }
    }

    private fun buildDnsQuery(domain: String): ByteArray {
        val buffer = ByteBuffer.allocate(512)
        buffer.putShort(0x1234) // ID
        buffer.putShort(0x0100) // Standard query
        buffer.putShort(1) // QDCOUNT
        buffer.putShort(0) // ANCOUNT
        buffer.putShort(0) // NSCOUNT
        buffer.putShort(0) // ARCOUNT

        for (label in domain.split(".")) {
            buffer.put(label.length.toByte())
            buffer.put(label.toByteArray())
        }
        buffer.put(0) // End of domain name
        buffer.putShort(1) // Type A
        buffer.putShort(1) // Class IN

        return buffer.array().copyOfRange(0, buffer.position())
    }

    private fun parseDnsResponse(response: ByteArray): List<String> {
        val ips = mutableListOf<String>()
        val answerCount = ((response[6].toInt() and 0xFF) shl 8) or (response[7].toInt() and 0xFF)
        var pointer = 12

        // Skip question section
        while (response[pointer].toInt() != 0) {
            pointer += (response[pointer].toInt() and 0xFF) + 1
        }
        pointer += 5 // Skip null byte + QTYPE + QCLASS

        for (i in 0 until answerCount) {
            pointer += 2 // Name (compressed)
            val type = ((response[pointer].toInt() and 0xFF) shl 8) or (response[pointer + 1].toInt() and 0xFF)
            pointer += 8 // Type + Class + TTL
            val dataLen = ((response[pointer].toInt() and 0xFF) shl 8) or (response[pointer + 1].toInt() and 0xFF)
            pointer += 2

            if (type == 1 && dataLen == 4) { // Type A
                val ip = "${response[pointer].toInt() and 0xFF}.${response[pointer + 1].toInt() and 0xFF}." +
                        "${response[pointer + 2].toInt() and 0xFF}.${response[pointer + 3].toInt() and 0xFF}"
                ips.add(ip)
            }
            pointer += dataLen
        }

        return ips
    }
}
