package com.cybersec.netspoof.utils

import android.content.Context
import android.net.wifi.WifiManager
import android.util.Log
import com.cybersec.netspoof.data.entities.Device
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.*
import java.util.*

data class ScannedDevice(
    val macAddress: String,
    val ipAddress: String,
    val deviceName: String,
    val manufacturer: String?,
    val deviceType: String,
    val isIoTDevice: Boolean,
    val lastSeen: Date,
    val isOnline: Boolean,
    val openPorts: List<Int>
)


class NetworkScanner(private val context: Context) {
    private val TAG = "NetworkScanner"

    suspend fun scanNetwork(): List<ScannedDevice> = withContext(Dispatchers.IO) {
        val devices = mutableListOf<ScannedDevice>()
        val networkInfo = getNetworkInfo()

        if (networkInfo != null) {
            val (baseIp, ipCount) = networkInfo

            // Create a list of IPs to scan
            val ipAddresses = mutableListOf<String>()
            val ipParts = baseIp.split(".")
            val prefix = ipParts.take(3).joinToString(".")

            // Scan common IP range (usually /24 networks)
            for (i in 1..254) {
                ipAddresses.add("$prefix.$i")
            }

            // Scan in parallel with a reasonable chunk size to avoid overwhelming the device
            val chunkSize = 10
            ipAddresses.chunked(chunkSize).forEach { chunk ->
                val scanJobs = chunk.map { ip ->
                    async {
                        scanDevice(ip)
                    }
                }

                devices.addAll(scanJobs.awaitAll().filterNotNull())

                // Small delay between chunks to be network-friendly
                delay(100)
            }
        }

        devices
    }

    private fun getNetworkInfo(): Pair<String, Int>? {
        val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val dhcpInfo = wifiManager.dhcpInfo

        if (dhcpInfo != null) {
            val ipAddress = dhcpInfo.ipAddress
            val netmask = dhcpInfo.netmask

            // Convert to IP string
            val ip = intToIp(ipAddress)

            // Calculate prefix length from netmask
            val prefixLength = Integer.bitCount(netmask)

            return Pair(ip, prefixLength)
        }

        return null
    }

    private fun intToIp(ip: Int): String {
        return "${ip and 0xFF}.${ip shr 8 and 0xFF}.${ip shr 16 and 0xFF}.${ip shr 24 and 0xFF}"
    }

    private suspend fun scanDevice(ipAddress: String): ScannedDevice? = withContext(Dispatchers.IO) {
        try {
            val inetAddress = InetAddress.getByName(ipAddress)

            // Use isReachable with a short timeout
            if (inetAddress.isReachable(500)) {
                // Try to get hostname
                val hostname = try {
                    inetAddress.hostName
                } catch (e: Exception) {
                    "Unknown"
                }

                // Try to get MAC address (this is best-effort and may not work on all devices)
                val macAddress = getMacFromArpCache(ipAddress) ?: "Unknown"

                // Scan a limited set of common ports with short timeouts
                val openPorts = scanLimitedPorts(ipAddress)

                // Determine if it's likely an IoT device
                val isIoTDevice = detectIoTDevice(hostname, openPorts)

                return@withContext ScannedDevice(
                    macAddress = macAddress,
                    ipAddress = ipAddress,
                    deviceName = hostname,
                    manufacturer = getManufacturer(macAddress),
                    deviceType = if (isIoTDevice) "IoT" else "Computer",
                    isIoTDevice = isIoTDevice,
                    lastSeen = Date(),
                    isOnline = true,
                    openPorts = openPorts
                )
            }
        } catch (e: Exception) {
            // Device not reachable or error occurred
            Log.d(TAG, "Could not reach device at $ipAddress: ${e.message}")
        }

        null
    }

    private fun getMacFromArpCache(ipAddress: String): String? {
        // This is a best-effort approach that doesn't require root
        try {
            // For local network devices, we can sometimes get MAC addresses
            // through standard Android APIs
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

            // For devices on the same network, we can try to get their MAC
            // through the NetworkInterface API if they're local
            val networkInterfaces = NetworkInterface.getNetworkInterfaces()
            while (networkInterfaces.hasMoreElements()) {
                val networkInterface = networkInterfaces.nextElement()
                val addresses = networkInterface.inetAddresses

                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (address.hostAddress == ipAddress) {
                        val mac = networkInterface.hardwareAddress
                        if (mac != null) {
                            return formatMacAddress(mac)
                        }
                    }
                }
            }

            // For non-local devices, we can't reliably get MAC addresses
            // without root access, so we'll generate a pseudo-MAC based on IP
            // This is just for identification purposes
            return generatePseudoMac(ipAddress)
        } catch (e: Exception) {
            Log.e(TAG, "Error getting MAC for IP $ipAddress", e)
        }

        return null
    }

    private fun formatMacAddress(mac: ByteArray): String {
        val sb = StringBuilder()
        for (i in mac.indices) {
            sb.append(String.format("%02X", mac[i]))
            if (i < mac.size - 1) {
                sb.append(":")
            }
        }
        return sb.toString()
    }

    private fun generatePseudoMac(ipAddress: String): String {
        // Generate a consistent pseudo-MAC based on IP address
        // This is NOT a real MAC but helps with device identification
        val parts = ipAddress.split(".")
        return "00:00:${parts[0].toInt().toString(16).padStart(2, '0')}:${parts[1].toInt().toString(16).padStart(2, '0')}:${parts[2].toInt().toString(16).padStart(2, '0')}:${parts[3].toInt().toString(16).padStart(2, '0')}"
    }

    private fun scanLimitedPorts(ipAddress: String): List<Int> {
        val openPorts = mutableListOf<Int>()
        // Scan only the most common ports with a very short timeout
        val commonPorts = listOf(80, 443, 8080, 8443, 22, 23, 21)

        for (port in commonPorts) {
            try {
                val socket = Socket()
                socket.connect(InetSocketAddress(ipAddress, port), 300) // 300ms timeout
                openPorts.add(port)
                socket.close()
            } catch (e: IOException) {
                // Port is closed or timeout
            }
        }

        return openPorts
    }

    private fun detectIoTDevice(hostname: String, openPorts: List<Int>): Boolean {
        val iotKeywords = listOf("camera", "thermostat", "light", "sensor", "smart", "iot")
        val iotPorts = listOf(8080, 8443, 554, 1935) // Common IoT ports

        val hasIoTKeyword = iotKeywords.any { keyword ->
            hostname.lowercase().contains(keyword)
        }

        val hasIoTPorts = openPorts.any { it in iotPorts }

        return hasIoTKeyword || hasIoTPorts
    }

    private fun getManufacturer(macAddress: String): String? {
        // In a real implementation, you would use an OUI database
        // to map MAC address prefixes to manufacturers
        if (macAddress == "Unknown" || !macAddress.contains(":")) {
            return "Unknown"
        }

        val prefix = macAddress.split(":").take(3).joinToString(":")

        return when {
            prefix.startsWith("00:50:56") -> "VMware"
            prefix.startsWith("08:00:27") -> "VirtualBox"
            prefix.startsWith("00:0C:29") -> "VMware"
            prefix.startsWith("00:00:") -> "Unknown (Local Network)"
            else -> "Unknown"
        }
    }
}
