package com.cybersec.netspoof.viewmodel.auth

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cybersec.netspoof.model.User
import com.cybersec.netspoof.repo.AuthRepository
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import kotlinx.coroutines.launch

class LoginViewModel : ViewModel() {
    private val authRepository = AuthRepository()

    // LiveData for login state
    private val _loginResult = MutableLiveData<Result<User>>()
    val loginResult: LiveData<Result<User>> = _loginResult

    // LiveData for loading state
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    // LiveData for password reset
    private val _passwordResetResult = MutableLiveData<Result<Unit>>()
    val passwordResetResult: LiveData<Result<Unit>> = _passwordResetResult

    // Initialize Google Sign-In
    fun initGoogleSignIn(context: Context) {
        authRepository.initGoogleSignIn(context)
    }

    // Get Google Sign-In Client
    fun getGoogleSignInClient(): GoogleSignInClient {
        return authRepository.getGoogleSignInClient()
    }

    // Check if user is already logged in
    fun isUserLoggedIn(): Boolean {
        return authRepository.isLoggedIn()
    }

    // Login with email and password
    fun login(email: String, password: String) {
        _isLoading.value = true
        viewModelScope.launch {
            val result = authRepository.login(email, password)
            _loginResult.value = result
            _isLoading.value = false
        }
    }

    // Handle Google Sign-In result
    fun handleGoogleSignInResult(completedTask: Task<GoogleSignInAccount>) {
        _isLoading.value = true
        viewModelScope.launch {
            try {
                val account = completedTask.getResult(ApiException::class.java)
                val result = authRepository.signInWithGoogle(account)
                _loginResult.value = result
            } catch (e: ApiException) {
                _loginResult.value = Result.failure(Exception("Google sign-in failed: ${e.statusCode}"))
            } finally {
                _isLoading.value = false
            }
        }
    }

    // Send password reset email
    fun sendPasswordResetEmail(email: String) {
        _isLoading.value = true
        viewModelScope.launch {
            val result = authRepository.sendPasswordResetEmail(email)
            _passwordResetResult.value = result
            _isLoading.value = false
        }
    }
}
