package com.cybersec.netspoof.viewmodel.auth

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cybersec.netspoof.model.User
import com.cybersec.netspoof.repo.AuthRepository
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import kotlinx.coroutines.launch

class RegisterViewModel : ViewModel() {
    private val authRepository = AuthRepository()

    // LiveData for registration state
    private val _registrationResult = MutableLiveData<Result<User>>()
    val registrationResult: LiveData<Result<User>> = _registrationResult

    // LiveData for loading state
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    // Initialize Google Sign-In
    fun initGoogleSignIn(context: Context) {
        authRepository.initGoogleSignIn(context)
    }

    // Get Google Sign-In Client
    fun getGoogleSignInClient(): GoogleSignInClient {
        return authRepository.getGoogleSignInClient()
    }

    // Register with email and password
    fun register(email: String, password: String, displayName: String = "") {
        _isLoading.value = true
        viewModelScope.launch {
            val result = authRepository.register(email, password, displayName)
            _registrationResult.value = result
            _isLoading.value = false
        }
    }

    // Handle Google Sign-In result
    fun handleGoogleSignInResult(completedTask: Task<GoogleSignInAccount>) {
        _isLoading.value = true
        viewModelScope.launch {
            try {
                val account = completedTask.getResult(ApiException::class.java)
                val result = authRepository.signInWithGoogle(account)
                _registrationResult.value = result
            } catch (e: ApiException) {
                _registrationResult.value = Result.failure(Exception("Google sign-in failed: ${e.statusCode}"))
            } finally {
                _isLoading.value = false
            }
        }
    }
}
