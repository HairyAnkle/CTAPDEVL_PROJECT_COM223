package com.cybersec.netspoof.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cybersec.netspoof.model.Device
import com.cybersec.netspoof.model.NetworkActivity
import com.cybersec.netspoof.model.NetworkStatus
import com.cybersec.netspoof.model.SecurityStatus
import com.cybersec.netspoof.model.Threat
import com.cybersec.netspoof.repo.NetworkRepository
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class DashboardViewModel(application: Application) : AndroidViewModel(application) {
    private val networkRepository = NetworkRepository(application)

    // LiveData for network status
    private val _networkStatus = MutableLiveData<NetworkStatus>()
    val networkStatus: LiveData<NetworkStatus> = _networkStatus

    // LiveData for active threats
    private val _activeThreats = MutableLiveData<List<Threat>>(emptyList())
    val activeThreats: LiveData<List<Threat>> = _activeThreats

    // LiveData for connected devices
    private val _connectedDevices = MutableLiveData<List<Device>>(emptyList())
    val connectedDevices: LiveData<List<Device>> = _connectedDevices

    // LiveData for recent activities
    private val _recentActivities = MutableLiveData<List<NetworkActivity>>(emptyList())
    val recentActivities: LiveData<List<NetworkActivity>> = _recentActivities

    // LiveData for scanning state
    private val _isScanning = MutableLiveData<Boolean>(false)
    val isScanning: LiveData<Boolean> = _isScanning

    // LiveData for errors
    private val _error = MutableLiveData<String?>(null)
    val error: LiveData<String?> = _error

    // Initialize data
    init {
        refreshData()
    }

    // Refresh all data
    fun refreshData() {
        fetchNetworkStatus()
        fetchActiveThreats()
        fetchConnectedDevices()
        fetchRecentActivities()
    }

    // Fetch network status
    private fun fetchNetworkStatus() {
        viewModelScope.launch {
            networkRepository.getNetworkStatus()
                .catch { e ->
                    _error.value = "Failed to get network status: ${e.message}"
                }
                .collect { status ->
                    _networkStatus.value = status
                }
        }
    }

    // Fetch active threats
    private fun fetchActiveThreats() {
        viewModelScope.launch {
            networkRepository.getActiveThreats()
                .catch { e ->
                    _error.value = "Failed to get threats: ${e.message}"
                }
                .collect { threats ->
                    _activeThreats.value = threats
                }
        }
    }

    // Fetch connected devices
    private fun fetchConnectedDevices() {
        viewModelScope.launch {
            networkRepository.getConnectedDevices()
                .catch { e ->
                    _error.value = "Failed to get devices: ${e.message}"
                }
                .collect { devices ->
                    _connectedDevices.value = devices
                }
        }
    }

    // Fetch recent activities
    private fun fetchRecentActivities() {
        viewModelScope.launch {
            networkRepository.getRecentActivities()
                .catch { e ->
                    _error.value = "Failed to get activities: ${e.message}"
                }
                .collect { activities ->
                    _recentActivities.value = activities
                }
        }
    }

    // Start a network scan
    fun startNetworkScan() {
        viewModelScope.launch {
            _isScanning.value = true
            networkRepository.startNetworkScan()
                .catch { e ->
                    _error.value = "Scan failed: ${e.message}"
                    _isScanning.value = false
                }
                .collect { progress ->
                    if (progress.progress == 100) {
                        _isScanning.value = false
                        refreshData()
                    }
                }
        }
    }

    // Clear error
    fun clearError() {
        _error.value = null
    }
}
