package com.cybersec.netspoof.viewmodel.devicedetail
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cybersec.netspoof.model.Device
import com.cybersec.netspoof.model.Port
import com.cybersec.netspoof.model.Vulnerability
import com.cybersec.netspoof.repo.NetworkRepository
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class DeviceDetailViewModel(application: Application) : AndroidViewModel(application) {
    private val networkRepository = NetworkRepository(application.applicationContext)

    // LiveData for device details
    private val _device = MutableLiveData<Device?>()
    val device: LiveData<Device?> = _device

    // LiveData for device ports
    private val _ports = MutableLiveData<List<Port>>(emptyList())
    val ports: LiveData<List<Port>> = _ports

    // LiveData for device vulnerabilities
    private val _vulnerabilities = MutableLiveData<List<Vulnerability>>(emptyList())
    val vulnerabilities: LiveData<List<Vulnerability>> = _vulnerabilities

    // LiveData for port scanning state
    private val _isPortScanning = MutableLiveData<Boolean>(false)
    val isPortScanning: LiveData<Boolean> = _isPortScanning

    // LiveData for vulnerability scanning state
    private val _isVulnerabilityScanning = MutableLiveData<Boolean>(false)
    val isVulnerabilityScanning: LiveData<Boolean> = _isVulnerabilityScanning

    // LiveData for errors
    private val _error = MutableLiveData<String?>(null)
    val error: LiveData<String?> = _error

    // Load device details
    fun loadDeviceDetails(deviceId: String) {
        viewModelScope.launch {
            networkRepository.getDeviceById(deviceId)
                .catch { e ->
                    _error.value = "Failed to load device: ${e.message}"
                }
                .collect { device ->
                    _device.value = device

                    // Load ports and vulnerabilities
                    if (device != null) {
                        loadDevicePorts(deviceId)
                        loadDeviceVulnerabilities(deviceId)
                    }
                }
        }
    }

    // Load device ports
    private fun loadDevicePorts(deviceId: String) {
        viewModelScope.launch {
            networkRepository.getDevicePorts(deviceId)
                .catch { e ->
                    _error.value = "Failed to load ports: ${e.message}"
                }
                .collect { ports ->
                    _ports.value = ports
                }
        }
    }

    // Load device vulnerabilities
    private fun loadDeviceVulnerabilities(deviceId: String) {
        viewModelScope.launch {
            networkRepository.getDeviceVulnerabilities(deviceId)
                .catch { e ->
                    _error.value = "Failed to load vulnerabilities: ${e.message}"
                }
                .collect { vulnerabilities ->
                    _vulnerabilities.value = vulnerabilities
                }
        }
    }

    // Start port scan
    fun startPortScan(deviceId: String) {
        viewModelScope.launch {
            _isPortScanning.value = true
            networkRepository.startPortScan(deviceId)
                .catch { e ->
                    _error.value = "Port scan failed: ${e.message}"
                    _isPortScanning.value = false
                }
                .collect { isComplete ->
                    if (isComplete) {
                        _isPortScanning.value = false
                        loadDevicePorts(deviceId)
                    }
                }
        }
    }

    // Start vulnerability scan
    fun startVulnerabilityScan(deviceId: String) {
        viewModelScope.launch {
            _isVulnerabilityScanning.value = true
            networkRepository.startVulnerabilityScan(deviceId)
                .catch { e ->
                    _error.value = "Vulnerability scan failed: ${e.message}"
                    _isVulnerabilityScanning.value = false
                }
                .collect { isComplete ->
                    if (isComplete) {
                        _isVulnerabilityScanning.value = false
                        loadDeviceVulnerabilities(deviceId)
                    }
                }
        }
    }

    // Clear error
    fun clearError() {
        _error.value = null
    }
}
