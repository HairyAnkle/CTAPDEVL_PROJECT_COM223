package com.cybersec.netspoof.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.cybersec.netspoof.model.Device
import com.cybersec.netspoof.model.ScanResult
import com.cybersec.netspoof.model.ScanResultItem
import com.cybersec.netspoof.model.Threat
import com.cybersec.netspoof.model.ThreatSeverity
import com.cybersec.netspoof.model.Vulnerability
import com.cybersec.netspoof.model.VulnerabilitySeverity
import com.cybersec.netspoof.repo.NetworkRepository
import com.cybersec.netspoof.repo.ScanType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Date
import java.util.UUID

class ScanViewModel(application: Application) : AndroidViewModel(application) {
    private val networkRepository = NetworkRepository(application)

    // LiveData for scan progress
    private val _scanProgress = MutableLiveData<Int>(0)
    val scanProgress: LiveData<Int> = _scanProgress

    // LiveData for scan status message
    private val _scanStatusMessage = MutableLiveData<String>("Ready to scan")
    val scanStatusMessage: LiveData<String> = _scanStatusMessage

    // LiveData for scan in progress
    private val _isScanning = MutableLiveData<Boolean>(false)
    val isScanning: LiveData<Boolean> = _isScanning

    // LiveData for scan results
    private val _scanResults = MutableLiveData<ScanResult?>(null)
    val scanResults: LiveData<ScanResult?> = _scanResults

    // LiveData for scan result items (for RecyclerView)
    private val _scanResultItems = MutableLiveData<List<ScanResultItem>>(emptyList())
    val scanResultItems: LiveData<List<ScanResultItem>> = _scanResultItems

    // LiveData for selected scan type
    private val _selectedScanType = MutableLiveData<ScanType>(ScanType.COMPREHENSIVE)
    val selectedScanType: LiveData<ScanType> = _selectedScanType

    // LiveData for errors
    private val _error = MutableLiveData<String?>(null)
    val error: LiveData<String?> = _error

    // LiveData for scan statistics
    private val _scanStats = MutableLiveData<ScanStatistics>()
    val scanStats: LiveData<ScanStatistics> = _scanStats

    // Set selected scan type
    fun setSelectedScanType(scanType: ScanType) {
        _selectedScanType.value = scanType
    }

    // Start scan
    fun startScan() {
        if (_isScanning.value == true) return

        _isScanning.value = true
        _scanProgress.value = 0
        _scanStatusMessage.value = "Starting scan..."
        _scanResultItems.value = emptyList()

        val startTime = System.currentTimeMillis()

        viewModelScope.launch {
            try {
                val scanType = _selectedScanType.value ?: ScanType.COMPREHENSIVE

                // Simulate scan progress for UI feedback
                val progressFlow = simulateScanProgress(scanType)

                // Collect progress updates
                progressFlow.collect { progress ->
                    _scanProgress.value = progress
                    updateScanStatusMessage(progress, scanType)
                }

                // Perform actual scan based on selected type
                val scanResults = performScan(scanType)

                // Calculate scan duration
                val duration = System.currentTimeMillis() - startTime

                // Create scan result
                val result = ScanResult(
                    id = UUID.randomUUID().toString(),
                    scanType = scanType,
                    scanDate = Date(),
                    duration = duration,
                    devicesScanned = scanResults.devices.size,
                    threatsFound = scanResults.threats.size,
                    vulnerabilitiesFound = scanResults.vulnerabilities.size,
                    devices = scanResults.devices,
                    threats = scanResults.threats,
                    vulnerabilities = scanResults.vulnerabilities
                )

                // Update LiveData
                _scanResults.value = result

                // Create scan result items for RecyclerView
                val resultItems = createScanResultItems(result)
                _scanResultItems.value = resultItems

                // Update scan statistics
                updateScanStatistics(result)

                // Save scan result to repository
                networkRepository.saveScanResult(result)

                _isScanning.value = false
                _scanStatusMessage.value = "Scan completed successfully"

            } catch (e: Exception) {
                _error.value = "Scan failed: ${e.message}"
                _isScanning.value = false
                _scanStatusMessage.value = "Scan failed"
            }
        }
    }

    private fun updateScanStatusMessage(progress: Int, scanType: ScanType) {
        _scanStatusMessage.value = when {
            progress < 20 -> "Initializing ${scanType.displayName} scan..."
            progress < 40 -> "Discovering devices on network..."
            progress < 60 -> "Analyzing network traffic..."
            progress < 80 -> "Checking for vulnerabilities..."
            progress < 95 -> "Processing results..."
            else -> "Finalizing scan..."
        }
    }

    private suspend fun simulateScanProgress(scanType: ScanType): Flow<Int> = flow {
        val totalDuration = when (scanType) {
            ScanType.ARP_SPOOFING -> 5000L
            ScanType.DNS_SPOOFING -> 8000L
            ScanType.VULNERABILITY -> 15000L
            ScanType.COMPREHENSIVE -> 20000L
        }

        val steps = 100
        val stepDuration = totalDuration / steps

        for (i in 1..steps) {
            emit(i)
            delay(stepDuration)
        }
    }

    private suspend fun performScan(scanType: ScanType): ScanResults = withContext(Dispatchers.IO) {
        val devices = mutableListOf<Device>()
        val threats = mutableListOf<Threat>()
        val vulnerabilities = mutableListOf<Vulnerability>()

        when (scanType) {
            ScanType.ARP_SPOOFING -> {
                // Perform ARP spoofing detection
                val arpThreats = networkRepository.detectArpSpoofing()
                threats.addAll(arpThreats)
            }
            ScanType.DNS_SPOOFING -> {
                // Perform DNS spoofing detection
                val dnsThreats = networkRepository.detectDnsSpoofing()
                threats.addAll(dnsThreats)
            }
            ScanType.VULNERABILITY -> {
                // Perform vulnerability scan
                val scanDevices = networkRepository.scanNetwork()
                devices.addAll(scanDevices)

                // Extract vulnerabilities from devices
                scanDevices.forEach { device ->
                    val deviceVulnerabilities = networkRepository.scanDeviceVulnerabilities(device.id)
                    vulnerabilities.addAll(deviceVulnerabilities)
                }
            }
            ScanType.COMPREHENSIVE -> {
                // Perform all scan types
                val arpThreats = networkRepository.detectArpSpoofing()
                threats.addAll(arpThreats)

                val dnsThreats = networkRepository.detectDnsSpoofing()
                threats.addAll(dnsThreats)

                val scanDevices = networkRepository.scanNetwork()
                devices.addAll(scanDevices)

                scanDevices.forEach { device ->
                    val deviceVulnerabilities = networkRepository.scanDeviceVulnerabilities(device.id)
                    vulnerabilities.addAll(deviceVulnerabilities)
                }
            }
        }

        return@withContext ScanResults(devices, threats, vulnerabilities)
    }

    private fun createScanResultItems(scanResult: ScanResult): List<ScanResultItem> {
        val resultItems = mutableListOf<ScanResultItem>()

        // Add threats as result items
        scanResult.threats.forEach { threat ->
            resultItems.add(
                ScanResultItem(
                    id = threat.id,
                    title = threat.title,
                    description = threat.description,
                    deviceInfo = threat.deviceIp ?: "Unknown device",
                    severity = threat.severity.name,
                    type = "THREAT"
                )
            )
        }

        // Add vulnerabilities as result items
        scanResult.vulnerabilities.forEach { vulnerability ->
            resultItems.add(
                ScanResultItem(
                    id = vulnerability.id,
                    title = vulnerability.title,
                    description = vulnerability.description,
                    deviceInfo = vulnerability.deviceIp ?: "Unknown device",
                    severity = vulnerability.severity.name,
                    type = "VULNERABILITY"
                )
            )
        }

        return resultItems
    }

    private fun updateScanStatistics(scanResult: ScanResult) {
        _scanStats.value = ScanStatistics(
            duration = formatDuration(scanResult.duration),
            threatsFound = scanResult.threatsFound,
            vulnerabilitiesFound = scanResult.vulnerabilitiesFound,
            devicesScanned = scanResult.devicesScanned,
            highSeverityCount = countHighSeverityIssues(scanResult),
            mediumSeverityCount = countMediumSeverityIssues(scanResult),
            lowSeverityCount = countLowSeverityIssues(scanResult)
        )
    }

    private fun formatDuration(durationMs: Long): String {
        val seconds = (durationMs / 1000) % 60
        val minutes = (durationMs / (1000 * 60)) % 60
        return "${minutes}m ${seconds}s"
    }

    private fun countHighSeverityIssues(scanResult: ScanResult): Int {
        val highThreats = scanResult.threats.count { it.severity == ThreatSeverity.HIGH || it.severity == ThreatSeverity.CRITICAL }
        val highVulnerabilities = scanResult.vulnerabilities.count { it.severity == VulnerabilitySeverity.HIGH || it.severity == VulnerabilitySeverity.CRITICAL }
        return highThreats + highVulnerabilities
    }

    private fun countMediumSeverityIssues(scanResult: ScanResult): Int {
        val mediumThreats = scanResult.threats.count { it.severity == ThreatSeverity.MEDIUM }
        val mediumVulnerabilities = scanResult.vulnerabilities.count { it.severity == VulnerabilitySeverity.MEDIUM }
        return mediumThreats + mediumVulnerabilities
    }

    private fun countLowSeverityIssues(scanResult: ScanResult): Int {
        val lowThreats = scanResult.threats.count { it.severity == ThreatSeverity.LOW }
        val lowVulnerabilities = scanResult.vulnerabilities.count { it.severity == VulnerabilitySeverity.LOW }
        return lowThreats + lowVulnerabilities
    }

    // Generate report
    fun generateReport() {
        val scanResult = _scanResults.value ?: return

        viewModelScope.launch {
            try {
                val reportId = networkRepository.generateReport(scanResult.id)
                _scanStatusMessage.value = "Report generated successfully (ID: $reportId)"
            } catch (e: Exception) {
                _error.value = "Failed to generate report: ${e.message}"
            }
        }
    }

    // Clear scan results
    fun clearScanResults() {
        _scanResults.value = null
        _scanResultItems.value = emptyList()
    }

    // Clear error
    fun clearError() {
        _error.value = null
    }

    data class ScanResults(
        val devices: List<Device> = emptyList(),
        val threats: List<Threat> = emptyList(),
        val vulnerabilities: List<Vulnerability> = emptyList()
    )

    data class ScanStatistics(
        val duration: String,
        val threatsFound: Int,
        val vulnerabilitiesFound: Int,
        val devicesScanned: Int,
        val highSeverityCount: Int,
        val mediumSeverityCount: Int,
        val lowSeverityCount: Int
    )
}
